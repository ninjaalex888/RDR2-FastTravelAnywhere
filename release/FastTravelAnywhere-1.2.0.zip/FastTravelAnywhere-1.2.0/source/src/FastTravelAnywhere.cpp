/*
    Fast Travel Anywhere  -  Red Dead Redemption 2 (Story Mode)
    A Script Hook RDR2 plugin (.asi)

    Hold E to kneel anywhere and the game shows its "Resting" menu in the
    bottom-right corner: Craft (R), Set Up Camp (E) and Leave (F). This plugin
    adds Fast Travel to that menu on Space (A on a controller), the same button
    a campfire uses. With a waypoint on the map, it takes you straight there,
    with your horse, and the clock moves on by the ride's length (see "Waypoint
    travel"). Without one, it runs the game's own fast travel: the same menu of
    places, and the same trip with your horse. And where the game leaves Set Up
    Camp out of the menu (in a town, say), it adds it, and the game makes camp
    at the nearest of its campsites (see "Set Up Camp anywhere").

    How the game does it (build 1491.50, from the decompiled game scripts)
    ----------------------------------------------------------------------
      * The kneel menu belongs to the dynamic_craft_scenario script. Its prompts
        sit in prompt group 342152817 ("REST_UI_GROUP", titled "Resting"),
        which that script draws every frame while you kneel.
      * A campfire's Fast Travel prompt (player_camp, interactive_campfire,
        sleeping_scenario) doesn't travel by itself. It sets bit 4 of
        Global_43907. The always-running short_update script (its "PLAYER CAMP
        FAST TRAVEL" module) sees the bit, builds the list of places, opens the
        FAST_TRAVEL_MENU app and keeps its progress in Global_43908:
          0 idle, 1 menu open, 2 place chosen, 4 and 5 travelling, 6 done.
      * While the menu is open, short_update closes it unless bit 23 of
        Global_1392040 is set. The campfire scripts set that bit while you're
        at the fire.
      * When you pick a place, short_update sets bit 8 and waits. The camp
        plays its kick-the-fire animation, the screen fades out, the camp packs
        up and sets bit 32. Then short_update takes your horse along (if it's
        within whistling range), loads the place and puts you on your horse.

    What this plugin does
    ---------------------
      * While the kneel menu is up, it adds a Fast Travel prompt to the same
        group, with the campfire's own text ("CAMP_FT_PROMPT"), so it reads
        "Fast Travel" in your game's language. That text lives in the game's
        CAMP text block, which the plugin loads when a kneel starts.
      * Pressing it sets bit 23 and bit 4, as a campfire does (once Arthur is
        all the way down: the menu doesn't stay open before that).
      * When you pick a place, it plays the camp's part: Arthur stands up, the
        screen fades out, then it sets bit 32 and the game does the rest.
      * It's greyed out when a campfire wouldn't offer fast travel either (not
        unlocked yet, wanted, on a mission, horse dead or too far away).
        Pressing it then shows the game's own message for the reason.

    Build: build.sh (zig, cross-compiles from Linux or macOS) or build_msvc.bat
    (Visual Studio). No Script Hook SDK files are needed: the plugin binds to
    ScriptHookRDR2.dll at runtime.
*/

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>

#ifdef _MSC_VER
#pragma comment(lib, "user32.lib")
#endif

#define FTA_NAME    "Fast Travel Anywhere"
#define FTA_VERSION "1.2.0"

// ===========================================================================
// Paths & logging
// ===========================================================================

static char g_iniPath[MAX_PATH + 8];
static char g_logPath[MAX_PATH + 8];

static void BuildPaths(HMODULE mod)
{
    char path[MAX_PATH] = { 0 };
    DWORD n = GetModuleFileNameA(mod, path, MAX_PATH);
    if (n == 0 || n >= MAX_PATH)
        strcpy(path, "FastTravelAnywhere.asi");

    char* dot   = strrchr(path, '.');
    char* slash = strrchr(path, '\\');
    if (dot && (!slash || dot > slash))
        *dot = 0;

    snprintf(g_iniPath, sizeof g_iniPath, "%s.ini", path);
    snprintf(g_logPath, sizeof g_logPath, "%s.log", path);
}

static void Log(const char* fmt, ...)
{
    if (!g_logPath[0])
        return;
    FILE* f = fopen(g_logPath, "a");
    if (!f)
        return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    fprintf(f, "[%02d:%02d:%02d.%03d] ", (int)st.wHour, (int)st.wMinute,
            (int)st.wSecond, (int)st.wMilliseconds);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static void ResetLog()
{
    FILE* f = fopen(g_logPath, "w");
    if (f)
        fclose(f);
}

// The game's string hash (Jenkins one-at-a-time on the lower-cased string),
// used for script names, control names and UI app names.
static uint32_t Joaat(const char* s)
{
    uint32_t h = 0;
    for (; *s; s++)
    {
        uint8_t c = (uint8_t)*s;
        if (c >= 'A' && c <= 'Z')
            c = (uint8_t)(c - 'A' + 'a');
        h += c;
        h += h << 10;
        h ^= h >> 6;
    }
    h += h << 3;
    h ^= h >> 11;
    h += h << 15;
    return h;
}

// ===========================================================================
// Settings (FastTravelAnywhere.ini, next to the .asi)
// ===========================================================================

struct Settings
{
    bool     enabled;
    bool     requireUnlock;
    bool     requireHorseNearby;
    bool     allowWhenWanted;
    bool     allowOnMissions;
    bool     showWhenUnavailable;
    bool     standUp;
    bool     showLoadMessage;
    bool     debugLog;
    bool     lockMovementInMenu;
    bool     campAnywhere;
    bool     waypointTravel;
    bool     advanceClock;
    uint32_t promptControl;
    char     promptControlName[64];
    char     promptText[96];
};

static Settings g_cfg;

static void DefaultSettings(Settings& s)
{
    memset(&s, 0, sizeof s);
    s.enabled             = true;
    s.requireUnlock       = true;
    s.requireHorseNearby  = true;
    s.allowWhenWanted     = false;
    s.allowOnMissions     = false;
    s.showWhenUnavailable = true;
    s.standUp             = true;
    s.showLoadMessage     = true;
    s.debugLog            = false;
    s.lockMovementInMenu  = false;
    s.campAnywhere        = true;
    s.waypointTravel      = true;
    s.advanceClock        = true;
    strcpy(s.promptControlName, "INPUT_CONTEXT_A");
    s.promptControl       = Joaat("INPUT_CONTEXT_A");
    s.promptText[0]       = 0;
}

// Written when the file is missing (CRLF, for Notepad).
static const char kDefaultIni[] =
    "; Fast Travel Anywhere settings.\r\n"
    "; Changes take effect within a couple of seconds, no restart needed.\r\n"
    "[FastTravelAnywhere]\r\n"
    "\r\n"
    "; 1 = add Fast Travel to the kneel menu, 0 = off\r\n"
    "Enabled=1\r\n"
    "\r\n"
    "; 1 = with a waypoint on the map, Fast Travel takes you straight there (to the road nearest\r\n"
    "; it, with your horse). Without a waypoint you get the game's fast travel menu as before,\r\n"
    "; and as Arthur also for a waypoint in New Austin or Blackwater, where the game keeps him out.\r\n"
    "; 0 = always the game's fast travel menu.\r\n"
    "WaypointTravel=1\r\n"
    "; 1 = the clock moves on by the ride's length when you travel to a waypoint\r\n"
    "; (the time the ride would take at a steady gallop). 0 = you arrive at the same time.\r\n"
    "AdvanceClock=1\r\n"
    "\r\n"
    "; 1 = Set Up Camp in the kneel menu wherever you kneel, towns included. Where the game\r\n"
    "; leaves it out, the mod adds it, and the game makes camp at the nearest of its campsites\r\n"
    "; (from a town, just outside it). Its other rules stay: not while wanted, in combat,\r\n"
    "; on a mission, indoors, on a train, in a gang hideout or with a camp already up. 0 = off.\r\n"
    "SetUpCampAnywhere=1\r\n"
    "\r\n"
    "; The game's own rules for fast travel at a campfire (1 = follow them):\r\n"
    "; fast travel has to be unlocked, as for your camp (Arthur: the lodging upgrade in the camp ledger).\r\n"
    "RequireUnlock=1\r\n"
    "; your horse has to be alive and within whistling range: it travels with you.\r\n"
    "; 0 = you can also go when your horse is too far away, and you arrive on foot.\r\n"
    "RequireHorseNearby=1\r\n"
    "; 1 = allow fast travel while you're wanted (a campfire doesn't)\r\n"
    "AllowWhenWanted=0\r\n"
    "; 1 = allow fast travel during a mission (a campfire doesn't)\r\n"
    "AllowOnMissions=0\r\n"
    "\r\n"
    "; 1 = show Fast Travel greyed out when you can't use it; pressing it says why.\r\n"
    "; 0 = hide it instead, as a campfire does.\r\n"
    "ShowWhenUnavailable=1\r\n"
    "; 1 = Arthur stands up as the screen fades out\r\n"
    "StandUp=1\r\n"
    "\r\n"
    "; The button, by the game's control name. INPUT_CONTEXT_A is Space (A on a controller),\r\n"
    "; the campfire's Fast Travel button. The kneel menu already uses R, E and F.\r\n"
    "PromptControl=INPUT_CONTEXT_A\r\n"
    "; Empty = the game's own \"Fast Travel\" text, in your game's language.\r\n"
    "PromptText=\r\n"
    "\r\n"
    "; 1 = show a short \"loaded\" message when Story Mode starts\r\n"
    "ShowLoadMessage=1\r\n"
    "; 1 = write more detail to FastTravelAnywhere.log\r\n"
    "DebugLog=0\r\n"
    "\r\n"
    "; Experimental. If the fast travel menu closes when you scroll it with W/S or the left stick\r\n"
    "; (Arthur gets up from the kneel), 1 switches the controls to menu-only while it's open.\r\n"
    "LockMovementInMenu=0\r\n";

static void Trim(char* s)
{
    char* p = s;
    while (*p == ' ' || *p == '\t')
        p++;
    if (p != s)
        memmove(s, p, strlen(p) + 1);
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n'))
        s[--n] = 0;
}

static bool ParseBool(const char* v, bool def)
{
    if (!_stricmp(v, "1") || !_stricmp(v, "true") || !_stricmp(v, "yes") || !_stricmp(v, "on"))
        return true;
    if (!_stricmp(v, "0") || !_stricmp(v, "false") || !_stricmp(v, "no") || !_stricmp(v, "off"))
        return false;
    return def;
}

// "INPUT_CONTEXT_A", "0x5181713D" or a decimal hash.
static uint32_t ParseControl(const char* v)
{
    if (!v[0])
        return 0;
    if ((v[0] == '0') && (v[1] == 'x' || v[1] == 'X'))
        return (uint32_t)strtoul(v + 2, nullptr, 16);
    bool digits = true;
    for (const char* p = v; *p; p++)
        if (*p < '0' || *p > '9')
            digits = false;
    if (digits)
        return (uint32_t)strtoul(v, nullptr, 10);
    return Joaat(v);
}

static FILETIME g_iniStamp = { 0, 0 };

static bool IniChanged()
{
    WIN32_FILE_ATTRIBUTE_DATA a;
    if (!GetFileAttributesExA(g_iniPath, GetFileExInfoStandard, &a))
        return g_iniStamp.dwLowDateTime != 0 || g_iniStamp.dwHighDateTime != 0;
    return CompareFileTime(&a.ftLastWriteTime, &g_iniStamp) != 0;
}

static void LoadSettings()
{
    DefaultSettings(g_cfg);

    FILE* f = fopen(g_iniPath, "rb");
    if (!f)
    {
        FILE* w = fopen(g_iniPath, "wb");
        if (w)
        {
            fwrite(kDefaultIni, 1, sizeof kDefaultIni - 1, w);
            fclose(w);
            Log("Settings: %s was missing, wrote the defaults.", g_iniPath);
        }
        else
        {
            Log("Settings: no %s and it couldn't be created; using the defaults.", g_iniPath);
        }
    }
    else
    {
        char line[512];
        while (fgets(line, sizeof line, f))
        {
            Trim(line);
            if (!line[0] || line[0] == ';' || line[0] == '#' || line[0] == '[')
                continue;
            char* eq = strchr(line, '=');
            if (!eq)
                continue;
            *eq = 0;
            char* key = line;
            char* val = eq + 1;
            Trim(key);
            Trim(val);

            if      (!_stricmp(key, "Enabled"))             g_cfg.enabled = ParseBool(val, g_cfg.enabled);
            else if (!_stricmp(key, "RequireUnlock"))       g_cfg.requireUnlock = ParseBool(val, g_cfg.requireUnlock);
            else if (!_stricmp(key, "RequireHorseNearby"))  g_cfg.requireHorseNearby = ParseBool(val, g_cfg.requireHorseNearby);
            else if (!_stricmp(key, "AllowWhenWanted"))     g_cfg.allowWhenWanted = ParseBool(val, g_cfg.allowWhenWanted);
            else if (!_stricmp(key, "AllowOnMissions"))     g_cfg.allowOnMissions = ParseBool(val, g_cfg.allowOnMissions);
            else if (!_stricmp(key, "ShowWhenUnavailable")) g_cfg.showWhenUnavailable = ParseBool(val, g_cfg.showWhenUnavailable);
            else if (!_stricmp(key, "StandUp"))             g_cfg.standUp = ParseBool(val, g_cfg.standUp);
            else if (!_stricmp(key, "ShowLoadMessage"))     g_cfg.showLoadMessage = ParseBool(val, g_cfg.showLoadMessage);
            else if (!_stricmp(key, "DebugLog"))            g_cfg.debugLog = ParseBool(val, g_cfg.debugLog);
            else if (!_stricmp(key, "LockMovementInMenu"))  g_cfg.lockMovementInMenu = ParseBool(val, g_cfg.lockMovementInMenu);
            else if (!_stricmp(key, "SetUpCampAnywhere"))   g_cfg.campAnywhere = ParseBool(val, g_cfg.campAnywhere);
            else if (!_stricmp(key, "WaypointTravel"))      g_cfg.waypointTravel = ParseBool(val, g_cfg.waypointTravel);
            else if (!_stricmp(key, "AdvanceClock"))        g_cfg.advanceClock = ParseBool(val, g_cfg.advanceClock);
            else if (!_stricmp(key, "PromptText"))
            {
                strncpy(g_cfg.promptText, val, sizeof g_cfg.promptText - 1);
                g_cfg.promptText[sizeof g_cfg.promptText - 1] = 0;
            }
            else if (!_stricmp(key, "PromptControl"))
            {
                uint32_t c = ParseControl(val);
                if (c)
                {
                    g_cfg.promptControl = c;
                    strncpy(g_cfg.promptControlName, val, sizeof g_cfg.promptControlName - 1);
                    g_cfg.promptControlName[sizeof g_cfg.promptControlName - 1] = 0;
                }
            }
        }
        fclose(f);
    }

    WIN32_FILE_ATTRIBUTE_DATA a;
    if (GetFileAttributesExA(g_iniPath, GetFileExInfoStandard, &a))
        g_iniStamp = a.ftLastWriteTime;

    Log("Settings: Enabled=%d WaypointTravel=%d AdvanceClock=%d SetUpCampAnywhere=%d RequireUnlock=%d "
        "RequireHorseNearby=%d AllowWhenWanted=%d "
        "AllowOnMissions=%d ShowWhenUnavailable=%d StandUp=%d PromptControl=%s (0x%08X) "
        "PromptText=\"%s\" DebugLog=%d LockMovementInMenu=%d",
        g_cfg.enabled, g_cfg.waypointTravel, g_cfg.advanceClock, g_cfg.campAnywhere, g_cfg.requireUnlock,
        g_cfg.requireHorseNearby, g_cfg.allowWhenWanted,
        g_cfg.allowOnMissions, g_cfg.showWhenUnavailable, g_cfg.standUp, g_cfg.promptControlName,
        g_cfg.promptControl, g_cfg.promptText, g_cfg.debugLog, g_cfg.lockMovementInMenu);
}

// ===========================================================================
// Script Hook RDR2 binding (resolved at runtime, no .lib needed)
// ===========================================================================

typedef void      (*ScriptMainFn)();
typedef void      (*PFN_scriptRegister)(HMODULE, ScriptMainFn);
typedef void      (*PFN_scriptUnregister)(HMODULE);
typedef void      (*PFN_scriptWait)(DWORD);
typedef void      (*PFN_nativeInit)(uint64_t);
typedef void      (*PFN_nativePush64)(uint64_t);
typedef uint64_t* (*PFN_nativeCall)();
typedef uint64_t* (*PFN_getGlobalPtr)(int);
typedef int       (*PFN_getGameVersion)();

static PFN_scriptRegister   SH_scriptRegister   = nullptr;
static PFN_scriptUnregister SH_scriptUnregister = nullptr;
static PFN_scriptWait       SH_scriptWait       = nullptr;
static PFN_nativeInit       SH_nativeInit       = nullptr;
static PFN_nativePush64     SH_nativePush64     = nullptr;
static PFN_nativeCall       SH_nativeCall       = nullptr;
static PFN_getGlobalPtr     SH_getGlobalPtr     = nullptr;
static PFN_getGameVersion   SH_getGameVersion   = nullptr;
static bool                 g_registered        = false;

// Script Hook exports C++ (MSVC-mangled) names. Try the exact name first, then
// fall back to scanning the export table by function-name prefix, so a small
// signature difference in a future Script Hook build still binds.
static FARPROC FindExport(HMODULE mod, const char* exact, const char* prefix,
                          const char* mustContain)
{
    FARPROC p = GetProcAddress(mod, exact);
    if (p)
        return p;

    BYTE* base = (BYTE*)mod;
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE)
        return nullptr;
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE)
        return nullptr;
    IMAGE_DATA_DIRECTORY dir =
        nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!dir.VirtualAddress || !dir.Size)
        return nullptr;

    IMAGE_EXPORT_DIRECTORY* exp = (IMAGE_EXPORT_DIRECTORY*)(base + dir.VirtualAddress);
    DWORD* names = (DWORD*)(base + exp->AddressOfNames);
    WORD*  ords  = (WORD*)(base + exp->AddressOfNameOrdinals);
    DWORD* funcs = (DWORD*)(base + exp->AddressOfFunctions);
    size_t plen  = strlen(prefix);

    for (DWORD i = 0; i < exp->NumberOfNames; i++)
    {
        const char* name = (const char*)(base + names[i]);
        if (strncmp(name, prefix, plen) != 0)
            continue;
        if (mustContain && !strstr(name, mustContain))
            continue;
        Log("Bound %s via export scan (%s)", prefix, name);
        return (FARPROC)(base + funcs[ords[i]]);
    }
    return nullptr;
}

static bool BindScriptHook()
{
    HMODULE sh = GetModuleHandleA("ScriptHookRDR2.dll");
    if (!sh)
        sh = LoadLibraryA("ScriptHookRDR2.dll");
    if (!sh)
    {
        Log("ERROR: ScriptHookRDR2.dll was not found next to RDR2.exe. "
            "Install Script Hook RDR2 (dev-c.com) first.");
        return false;
    }

    SH_scriptRegister = (PFN_scriptRegister)FindExport(
        sh, "?scriptRegister@@YAXPEAUHINSTANCE__@@P6AXXZ@Z", "?scriptRegister@@", nullptr);
    SH_scriptUnregister = (PFN_scriptUnregister)FindExport(
        sh, "?scriptUnregister@@YAXPEAUHINSTANCE__@@@Z", "?scriptUnregister@@", "HINSTANCE");
    SH_scriptWait = (PFN_scriptWait)FindExport(
        sh, "?scriptWait@@YAXK@Z", "?scriptWait@@", nullptr);
    SH_nativeInit = (PFN_nativeInit)FindExport(
        sh, "?nativeInit@@YAX_K@Z", "?nativeInit@@", nullptr);
    SH_nativePush64 = (PFN_nativePush64)FindExport(
        sh, "?nativePush64@@YAX_K@Z", "?nativePush64@@", nullptr);
    SH_nativeCall = (PFN_nativeCall)FindExport(
        sh, "?nativeCall@@YAPEA_KXZ", "?nativeCall@@", nullptr);
    SH_getGlobalPtr = (PFN_getGlobalPtr)FindExport(
        sh, "?getGlobalPtr@@YAPEA_KH@Z", "?getGlobalPtr@@", nullptr);
    SH_getGameVersion = (PFN_getGameVersion)FindExport(
        sh, "?getGameVersion@@YA?AW4eGameVersion@@XZ", "?getGameVersion@@", nullptr);

    if (!SH_scriptRegister || !SH_scriptWait || !SH_nativeInit ||
        !SH_nativePush64 || !SH_nativeCall)
    {
        Log("ERROR: could not find required Script Hook functions "
            "(register=%p wait=%p init=%p push=%p call=%p). "
            "Your Script Hook RDR2 may be too old or too new for this build.",
            (void*)SH_scriptRegister, (void*)SH_scriptWait, (void*)SH_nativeInit,
            (void*)SH_nativePush64, (void*)SH_nativeCall);
        return false;
    }
    if (!SH_getGlobalPtr)
        Log("ERROR: Script Hook has no getGlobalPtr. Fast travel can't be started without it.");
    return true;
}

// ===========================================================================
// Native calls
// ===========================================================================

template <typename T>
static inline void PushArg(T v)
{
    static_assert(sizeof(T) <= sizeof(uint64_t), "native argument too large");
    uint64_t raw = 0;
    memcpy(&raw, &v, sizeof(T)); // floats occupy the low 4 bytes, like the SDK
    SH_nativePush64(raw);
}

static inline void PushArgs() {}

template <typename T, typename... Rest>
static inline void PushArgs(T first, Rest... rest)
{
    PushArg(first);
    PushArgs(rest...);
}

template <typename R, typename... A>
static inline R Invoke(uint64_t hash, A... args)
{
    SH_nativeInit(hash);
    PushArgs(args...);
    uint64_t* res = SH_nativeCall();
    R out;
    memcpy(&out, res, sizeof(R));
    return out;
}

template <typename... A>
static inline void InvokeVoid(uint64_t hash, A... args)
{
    SH_nativeInit(hash);
    PushArgs(args...);
    SH_nativeCall();
}

// Hashes from alloc8or's RDR3 native DB (github.com/alloc8or/rdr3-nativedb-data).
namespace N
{
    // A Vector3 the way the Script Hook SDK lays it out: three floats, each in an 8-byte slot.
    struct Vec3 { float x; uint32_t padX; float y; uint32_t padY; float z; uint32_t padZ; };

    static inline int  PlayerPedId()             { return Invoke<int>(0x096275889B8E0EE0ULL); }                    // PLAYER::PLAYER_PED_ID
    static inline int  PlayerId()                { return Invoke<int>(0x217E9DC48139933DULL); }                    // PLAYER::PLAYER_ID
    static inline bool IsEntityDead(int e)       { return Invoke<int>(0x7D5B1F88E7504BBAULL, e) != 0; }           // ENTITY::IS_ENTITY_DEAD
    static inline bool DoesEntityExist(int e)    { return Invoke<int>(0xD42BD6EB2E0F1677ULL, e) != 0; }           // ENTITY::DOES_ENTITY_EXIST
    static inline Vec3 EntityCoords(int e)       { return Invoke<Vec3>(0xA86D5F069399F44DULL, e, 1, 0); }         // ENTITY::GET_ENTITY_COORDS(entity, alive, realCoords)
    static inline bool IsEntityAPed(int e)       { return Invoke<int>(0xCF8176912DDA4EA5ULL, e) != 0; }           // ENTITY::IS_ENTITY_A_PED
    static inline bool IsPedInWrithe(int p)      { return Invoke<int>(0xDEB6D52126E7D640ULL, p) != 0; }           // TASK::IS_PED_IN_WRITHE
    static inline bool IsPedHuman(int p)         { return Invoke<int>(0xB980061DA992779DULL, p) != 0; }           // PED::IS_PED_HUMAN
    static inline bool IsModelValid(uint32_t m)  { return Invoke<int>(0x392C8D8E07B70EFCULL, m) != 0; }           // STREAMING::IS_MODEL_VALID
    static inline bool IsPedInAnyVehicle(int p)  { return Invoke<int>(0x997ABD671D25CA0BULL, p, 0) != 0; }        // PED::IS_PED_IN_ANY_VEHICLE
    static inline bool IsPedInAnyTrain(int p)    { return Invoke<int>(0x6F972C1AB75A1ED0ULL, p) != 0; }           // PED::IS_PED_IN_ANY_TRAIN
    static inline bool IsPedOnMount(int p)       { return Invoke<int>(0x460BC76A0E10655EULL, p) != 0; }           // PED::IS_PED_ON_MOUNT

    static inline int  ScriptThreads(uint32_t h) { return Invoke<int>(0x8E34C953364A76DDULL, h); }                // SCRIPT::GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH
    static inline void ThreadIteratorReset()     { InvokeVoid(0x39382EB8DCD8684DULL); }                           // SCRIPT::SCRIPT_THREAD_ITERATOR_RESET
    static inline int  ThreadIteratorNext()      { return Invoke<int>(0x3CE3FB167E837D7CULL); }                    // SCRIPT::SCRIPT_THREAD_ITERATOR_GET_NEXT_THREAD_ID
    static inline uint32_t HashOfThread(int id)  { return Invoke<uint32_t>(0x724CB89D35B283D0ULL, id); }           // SCRIPT::_GET_HASH_OF_THREAD
    static inline bool DoesScriptExist(const char* s)  { return Invoke<int>(0x552B171E3F69E5AEULL, s) != 0; }      // SCRIPT::DOES_SCRIPT_EXIST
    static inline void RequestScript(const char* s)    { InvokeVoid(0x46ED607DDD40D7FEULL, s); }                  // SCRIPT::REQUEST_SCRIPT
    static inline bool HasScriptLoaded(const char* s)  { return Invoke<int>(0xE97BD36574F8B0A6ULL, s) != 0; }      // SCRIPT::HAS_SCRIPT_LOADED
    static inline void ScriptNoLongerNeeded(const char* s) { InvokeVoid(0x0086D3067E1CFD1CULL, s); }              // SCRIPT::SET_SCRIPT_AS_NO_LONGER_NEEDED
    static inline int  StartScriptWithArgs(const char* s, uint64_t* args, int argc, int stack)
    { return Invoke<int>(0xB8BA7F44DF1575E1ULL, s, args, argc, stack); }                                          // SCRIPT::START_NEW_SCRIPT_WITH_ARGS

    // Inventory (the camp kit)
    static inline bool ItemKeyValid(uint32_t item)        { return Invoke<int>(0x6D5D51B188333FD1ULL, item, 0) != 0; } // ITEMDATABASE::_ITEMDATABASE_IS_KEY_VALID
    static inline bool UsingBackupInventory()             { return Invoke<int>(0x7C7E4AB748EA3B07ULL) != 0; }    // INVENTORY::_INVENTORY_IS_USING_BACKUP_INVENTORY
    static inline int  ItemCount(int inv, uint32_t item)  { return Invoke<int>(0xE787F05DFC977BDEULL, inv, item, 0); } // INVENTORY::_INVENTORY_GET_INVENTORY_ITEM_COUNT_WITH_ITEMID

    // What the game checks before it lets you make camp (dynamic_craft_scenario func_21)
    static inline bool IsInteriorScene()             { return Invoke<int>(0x4200F14D6F840A9AULL) != 0; }        // INTERIOR::IS_INTERIOR_SCENE
    static inline bool IsPedInCombat(int p)          { return Invoke<int>(0x4859F1FC66A6278EULL, p, 0) != 0; }  // PED::IS_PED_IN_COMBAT
    static inline bool RecentCrime(int player)       { return Invoke<int>(0x26934083D3F2579CULL, player) != 0; } // LAW::_0x26934083D3F2579C ("recently committed a crime")
    static inline bool IsMinigameInProgress()        { return Invoke<int>(0xF4D8BCD052E7EA1BULL) != 0; }        // MISC::IS_MINIGAME_IN_PROGRESS
    static inline bool IsAnimalInteractionRunning(int p) { return Invoke<int>(0x7FC84E85D98F063DULL, p) != 0; } // PED::_IS_ANIMAL_INTERACTION_RUNNING
    static inline bool IsPedOnVehicle(int p)         { return Invoke<int>(0x67722AEB798E5FABULL, p, 0) != 0; }  // PED::IS_PED_ON_VEHICLE
    static inline bool IsPedRagdoll(int p)           { return Invoke<int>(0x47E4E977581C5B55ULL, p) != 0; }     // PED::IS_PED_RAGDOLL
    static inline bool IsPedInAnyBoat(int p)         { return Invoke<int>(0x2E0E1C2B4F6CB339ULL, p) != 0; }     // PED::IS_PED_IN_ANY_BOAT
    static inline bool IsPlayerRidingTrain(int pl)   { return Invoke<int>(0x2FB0ACADA6A238DDULL, pl) != 0; }    // PLAYER::IS_PLAYER_RIDING_TRAIN
    static inline bool IsPedJacking(int p)           { return Invoke<int>(0x4AE4FF911DFB61DAULL, p) != 0; }     // PED::IS_PED_JACKING
    // Named _INVENTORY_IS_INVENTORY_ITEM_EQUIPPED in the native DB, but it reads whether a script
    // has the item disabled (alternative name _INVENTORY_IS_ITEM_DISABLED; see rcm_collect_dinosaur_bones11).
    static inline bool ItemDisabled(int inv, uint32_t item, int p2)
    { return Invoke<int>(0x3D10D7179D7034AFULL, inv, item, p2) != 0; }                                          // INVENTORY::_INVENTORY_IS_INVENTORY_ITEM_EQUIPPED

    // The kneel. dynamic_craft_scenario shows its prompts once the kneel's
    // animation event fires or IS_PED_ACTIVE_IN_SCENARIO(player, 0), while the
    // player has no interaction target.
    static inline bool IsPedActiveInScenario(int p) { return Invoke<int>(0xAA135F9482C82CC3ULL, p, 0) != 0; }     // TASK::IS_PED_ACTIVE_IN_SCENARIO
    static inline bool IsPedExitingScenario(int p)  { return Invoke<int>(0x0C3CB2E600C8977DULL, p, 1) != 0; }     // TASK::IS_PED_EXITING_SCENARIO
    static inline bool IsPedRunningItemInteraction(int p) { return Invoke<int>(0xEC7E480FF8BD0BEDULL, p) != 0; } // TASK::IS_PED_RUNNING_TASK_ITEM_INTERACTION
    static inline bool PedHasUseScenarioTask(int p) { return Invoke<int>(0x295E3CCEC879CCD7ULL, p) != 0; }        // TASK::PED_HAS_USE_SCENARIO_TASK
    static inline bool PedIsInScenarioBase(int p)   { return Invoke<int>(0x02EBBB3989B7E695ULL, p) != 0; }        // TASK::_PED_IS_IN_SCENARIO_BASE
    static inline bool PlayerHasInteractionTarget(int player)
    {
        int64_t target = 0;  // Entity* out-parameter: give it a full 8-byte slot
        return Invoke<int>(0x3EE1F7A8C32F24E1ULL, player, &target, 0, 0) != 0;                                    // PLAYER::GET_PLAYER_INTERACTION_TARGET_ENTITY
    }

    // Prompts
    static inline int  PromptRegisterBegin()                  { return Invoke<int>(0x04F97DE45A519419ULL); }      // HUD::_UI_PROMPT_REGISTER_BEGIN
    static inline void PromptSetControlAction(int p, uint32_t a) { InvokeVoid(0xB5352B7494A08258ULL, p, a); }     // HUD::_UI_PROMPT_SET_CONTROL_ACTION
    static inline void PromptSetText(int p, const char* t)    { InvokeVoid(0x5DD02A8318420DD7ULL, p, t); }        // HUD::_UI_PROMPT_SET_TEXT
    static inline void PromptSetPriority(int p, int v)        { InvokeVoid(0xCA24F528D0D16289ULL, p, v); }        // HUD::_UI_PROMPT_SET_PRIORITY
    static inline void PromptSetTransportMode(int p, int v)   { InvokeVoid(0x876E4A35C73A6655ULL, p, v); }        // HUD::_UI_PROMPT_SET_TRANSPORT_MODE
    static inline void PromptSetAttribute(int p, int a, int on) { InvokeVoid(0x560E76D5E2E1803FULL, p, a, on); }  // HUD::_UI_PROMPT_SET_ATTRIBUTE
    static inline void PromptSetStandardMode(int p, int release) { InvokeVoid(0xCC6656799977741BULL, p, release); } // HUD::_UI_PROMPT_SET_STANDARD_MODE
    static inline void PromptRegisterEnd(int p)               { InvokeVoid(0xF7AA2696A22AD8B9ULL, p); }           // HUD::_UI_PROMPT_REGISTER_END
    static inline void PromptSetGroup(int p, int g, int tab)  { InvokeVoid(0x2F11D3A254169EA4ULL, p, g, tab); }   // HUD::_UI_PROMPT_SET_GROUP
    static inline void PromptSetEnabled(int p, int on)        { InvokeVoid(0x8A0FB4D03A630D21ULL, p, on); }       // HUD::_UI_PROMPT_SET_ENABLED
    static inline void PromptSetVisible(int p, int on)        { InvokeVoid(0x71215ACCFDE075EEULL, p, on); }       // HUD::_UI_PROMPT_SET_VISIBLE
    static inline bool PromptIsJustReleased(int p)            { return Invoke<int>(0x635CC82FA297A827ULL, p) != 0; } // HUD::_UI_PROMPT_IS_JUST_RELEASED
    static inline bool PromptIsJustPressed(int p)             { return Invoke<int>(0x2787CC611D3FACC5ULL, p) != 0; } // HUD::_UI_PROMPT_IS_JUST_PRESSED
    static inline bool PromptIsValid(int p)                   { return Invoke<int>(0x347469FBDD1589A9ULL, p) != 0; } // HUD::_UI_PROMPT_IS_VALID
    static inline void PromptDelete(int p)                    { InvokeVoid(0x00EDE88D4D13CF59ULL, p); }           // HUD::_UI_PROMPT_DELETE

    // UI apps
    static inline bool IsUiAppActive(uint32_t h)   { return Invoke<int>(0x25B7A0206BDFAC76ULL, h) != 0; }        // UIAPPS::IS_UIAPP_ACTIVE_BY_HASH
    static inline bool CanLaunchUiApp(uint32_t h)  { return Invoke<int>(0xE555EC27D65EDE80ULL, h) != 0; }        // UIAPPS::CAN_LAUNCH_UIAPP_BY_HASH

    // Text
    static inline const char* VarStringLiteral(const char* text)
    { return Invoke<const char*>(0xFA925AC00EB830B9ULL, 10, "LITERAL_STRING", text); }                           // MISC::VAR_STRING
    static inline int  PostHelpText(int64_t* data, int64_t* text, int immediately)
    { return Invoke<int>(0x049D5C615BD38BADULL, data, text, immediately); }                                       // UIFEED::_UI_FEED_POST_HELP_TEXT
    static inline bool TextBlockIsLoaded(const char* b)       { return Invoke<int>(0xD0976CC34002DB57ULL, b) != 0; } // HUD::TEXT_BLOCK_IS_LOADED
    static inline void TextBlockRequest(const char* b)        { InvokeVoid(0xF66090013DE648D5ULL, b); }           // HUD::TEXT_BLOCK_REQUEST
    static inline void TextBlockDelete(const char* b)         { InvokeVoid(0xAA03F130A637D923ULL, b); }           // HUD::_TEXT_BLOCK_DELETE
    static inline bool DoesTextBlockExist(const char* b)      { return Invoke<int>(0x2C729F2B94CEA911ULL, b) != 0; } // HUD::_DOES_TEXT_BLOCK_EXIST
    static inline bool DoesTextLabelExist(const char* l)      { return Invoke<int>(0x73C258C68D6F55B6ULL, l) != 0; } // HUD::DOES_TEXT_LABEL_EXIST
    static inline const char* LabelText(const char* l)        { return Invoke<const char*>(0x3429670F9B9EF2D3ULL, l); } // HUD::_GET_LABEL_TEXT_2
    static inline void BgSetTextScale(float sx, float sy)     { InvokeVoid(0xA1253A3C870B6843ULL, sx, sy); }      // UIDEBUG::_BG_SET_TEXT_SCALE
    static inline void BgSetTextColor(int r, int g, int b, int a) { InvokeVoid(0x16FA5CE47F184F1EULL, r, g, b, a); } // UIDEBUG::_BG_SET_TEXT_COLOR
    static inline void BgDisplayText(const char* vs, float x, float y) { InvokeVoid(0x16794E044C9EFB58ULL, vs, x, y); } // UIDEBUG::_BG_DISPLAY_TEXT

    // Game state
    static inline int  GameTimer()                 { return Invoke<int>(0x4F67E8ECA7D3F667ULL); }                // MISC::GET_GAME_TIMER
    static inline bool MissionFlag()               { return Invoke<int>(0xB15CD1CF58771DE1ULL) != 0; }           // MISC::GET_MISSION_FLAG
    static inline bool IsLawIncidentActive(int pl) { return Invoke<int>(0xAD401C63158ACBAAULL, pl) != 0; }       // LAW::IS_LAW_INCIDENT_ACTIVE
    static inline bool IsPauseMenuActive()         { return Invoke<int>(0x535384D6067BA42EULL) != 0; }           // HUD::IS_PAUSE_MENU_ACTIVE
    static inline bool IsLoadingScreenActive()     { return Invoke<int>(0x71D4BF5890659B0CULL) != 0; }           // DLC::GET_IS_LOADING_SCREEN_ACTIVE
    static inline bool NetworkIsSessionStarted()   { return Invoke<int>(0x9DE624D2FC4B603FULL) != 0; }           // NETWORK::NETWORK_IS_SESSION_STARTED
    static inline bool NetworkIsGameInProgress()   { return Invoke<int>(0x10FAB35428CCC9D7ULL) != 0; }           // NETWORK::NETWORK_IS_GAME_IN_PROGRESS

    // Controls (pad 0, as the game's scripts use)
    static inline void DisableControlAction(uint32_t a)        { InvokeVoid(0xFE99B66D079CF6BCULL, 0, a, 0); }  // PAD::DISABLE_CONTROL_ACTION
    static inline void DisableAllControlActions()              { InvokeVoid(0x5F4B6931816E599BULL, 0); }        // PAD::DISABLE_ALL_CONTROL_ACTIONS
    static inline void EnableControlAction(uint32_t a)         { InvokeVoid(0x351220255D64C155ULL, 0, a, 1); }  // PAD::ENABLE_CONTROL_ACTION
    static inline float DisabledControlNormal(uint32_t a)      { return Invoke<float>(0x11E65974A982637CULL, 0, a); } // PAD::GET_DISABLED_CONTROL_NORMAL
    static inline void SetControlContext(int layer, uint32_t ctx) { InvokeVoid(0x2804658EB7D8A50BULL, layer, ctx); } // PAD::_SET_CONTROL_CONTEXT (every frame)
    static inline bool IsDisabledControlJustReleased(uint32_t a) { return Invoke<int>(0x305C8DCD79DA8B0FULL, 0, a) != 0; } // PAD::IS_DISABLED_CONTROL_JUST_RELEASED
    static inline bool IsControlActionValid(uint32_t a)        { return Invoke<int>(0xBC0884BC590951C7ULL, a, 0) != 0; } // PAD::_IS_CONTROL_ACTION_VALID(action, control)

    // Screen
    static inline void FadeOut(int ms)  { InvokeVoid(0x40C719A5E410B9E4ULL, ms); }                               // CAMERA::DO_SCREEN_FADE_OUT
    static inline void FadeIn(int ms)   { InvokeVoid(0x6A053CF596F67DF7ULL, ms); }                               // CAMERA::DO_SCREEN_FADE_IN
    static inline bool IsFadedOut()     { return Invoke<int>(0xF5472C80DF2FF847ULL) != 0; }                      // CAMERA::IS_SCREEN_FADED_OUT
    static inline bool IsFadingOut()    { return Invoke<int>(0x02F39BEFE7B88D00ULL) != 0; }                      // CAMERA::IS_SCREEN_FADING_OUT
    static inline bool IsFadingIn()     { return Invoke<int>(0x0CECCC63FFA2EF24ULL) != 0; }                      // CAMERA::IS_SCREEN_FADING_IN
    static inline bool IsFadedIn()      { return Invoke<int>(0x37F9A426FBCF4AF2ULL) != 0; }                      // CAMERA::IS_SCREEN_FADED_IN

    // The player
    static inline void GivePedHashCommand(int p, uint32_t cmd, float t) { InvokeVoid(0xD65FDC686A031C83ULL, p, cmd, t); } // PED::_GIVE_PED_HASH_COMMAND
    static inline void ClearPedTasksImmediately(int p)        { InvokeVoid(0xAAA34F8A7CB32098ULL, p, 0, 1); }     // TASK::CLEAR_PED_TASKS_IMMEDIATELY(ped, p1, resetCrouch)
    static inline void SetPedConfigFlag(int p, int flag, int on) { InvokeVoid(0x1913FE4CBF41C463ULL, p, flag, on); } // PED::SET_PED_CONFIG_FLAG
    static inline void TriggerMusicEvent(const char* e)       { Invoke<int>(0x706D57B0F50DA710ULL, e); }          // AUDIO::TRIGGER_MUSIC_EVENT

    // Waypoint travel: the map's waypoint and the GPS route to it
    static inline bool IsWaypointActive()    { return Invoke<int>(0x202B1BBFC6AB5EE4ULL) != 0; }                  // MAP::IS_WAYPOINT_ACTIVE
    static inline Vec3 WaypointCoords()      { return Invoke<Vec3>(0x29B30D07C3F7873BULL); }                       // MAP::_GET_WAYPOINT_COORDS (z is always 0)
    static inline bool ClosestGpsPosition(float x, float y, float z, Vec3* out)
    { return Invoke<int>(0x3FDA2B79AEEE351CULL, x, y, z, out) != 0; }                                            // MAP::_FIND_CLOSEST_GPS_POSITION
    static inline bool GpsRouteFound()       { return Invoke<int>(0x869DAACBBE9FA006ULL) != 0; }                  // PATH::GET_GPS_BLIP_ROUTE_FOUND
    static inline int  GpsRouteLength()      { return Invoke<int>(0xBBB45C3CF5C8AA85ULL); }                        // PATH::GET_GPS_BLIP_ROUTE_LENGTH (metres)
    static inline bool GpsPathOnRoad()       { return Invoke<int>(0xF47A1EB2A538A3A3ULL) != 0; }                  // MAP::_IS_PATH_FOR_GPS_ON_ROAD
    static inline bool SafeCoordForPed(float x, float y, float z, Vec3* out, int flags)
    { return Invoke<int>(0xB61C8E878A4199CAULL, x, y, z, 0, out, flags) != 0; }                                  // PATH::GET_SAFE_COORD_FOR_PED(x, y, z, onGround, out, flags)
    static inline bool NavmeshLoadedIn(float x1, float y1, float z1, float x2, float y2, float z2)
    { return Invoke<int>(0xF813C7E63F9062A5ULL, x1, y1, z1, x2, y2, z2) != 0; }                                  // PATH::IS_NAVMESH_LOADED_IN_AREA
    // The map's zones (mapzones.meta), by type: 0 state, 1 town, 10 district
    static inline uint32_t MapZoneAt(float x, float y, float z, int type)
    { return Invoke<uint32_t>(0x43AD8FC02B429D33ULL, x, y, z, type); }                                           // ZONE::_GET_MAP_ZONE_AT_COORDS
    static inline uint32_t EntityModel(int e)        { return Invoke<uint32_t>(0xDA76A9F39210D365ULL, e); }       // ENTITY::GET_ENTITY_MODEL
    // Water below (x, y, z): 0 none, 1 water (its surface's height out), 2 something solid first
    static inline int  WaterProbe(float x, float y, float z, float* surface)
    {
        uint64_t slot = 0;   // float* out-parameter: give it a full 8-byte slot
        int r = Invoke<int>(0x2B3451FA1E3142E2ULL, x, y, z, 1, &slot);                                          // WATER::TEST_VERTICAL_PROBE_AGAINST_ALL_WATER
        memcpy(surface, &slot, sizeof(float));
        return r;
    }
    // ...streaming the place in (p4 1, as the train's trip does: train_fast_travel_core)
    static inline bool LoadSceneStartSphere(float x, float y, float z, float r)
    { return Invoke<int>(0x513F8AA5BF2F17CFULL, x, y, z, r, 1) != 0; }                                           // STREAMING::LOAD_SCENE_START_SPHERE
    static inline bool IsLoadSceneActive()   { return Invoke<int>(0xCF45DF50C7775F2AULL) != 0; }                  // STREAMING::IS_LOAD_SCENE_ACTIVE
    static inline bool IsLoadSceneLoaded()   { return Invoke<int>(0x0909F71B5C070797ULL) != 0; }                  // STREAMING::IS_LOAD_SCENE_LOADED
    static inline void LoadSceneStop()       { InvokeVoid(0x5A8B01199C3E79C3ULL); }                                // STREAMING::LOAD_SCENE_STOP
    static inline void RequestCollisionAt(float x, float y, float z) { InvokeVoid(0x0A3720F162A033C9ULL, x, y, z); } // STREAMING::REQUEST_COLLISION_AT_COORD
    static inline bool CollisionLoadedAround(int e) { return Invoke<int>(0xBEB1600952B9CF5CULL, e) != 0; }        // ENTITY::HAS_COLLISION_LOADED_AROUND_ENTITY
    static inline bool GroundZ(float x, float y, float z, float* out)
    {
        uint64_t slot = 0;   // float* out-parameter: give it a full 8-byte slot
        bool ok = Invoke<int>(0x24FA4267BB8D2431ULL, x, y, z, &slot, 0) != 0;                                    // MISC::GET_GROUND_Z_FOR_3D_COORD
        memcpy(out, &slot, sizeof(float));
        return ok;
    }
    // ...and putting the player and the horses there
    static inline void SetEntityCoords(int e, float x, float y, float z)
    { InvokeVoid(0x06843DA7060A026BULL, e, x, y, z, 1, 0, 1, 1); }                                                // ENTITY::SET_ENTITY_COORDS (1, 0, 1, 1: as train_fast_travel_core moves the player)
    static inline void SetEntityCoordsAndHeading(int e, float x, float y, float z, float h)
    { InvokeVoid(0x203BEFFDBE12E96AULL, e, x, y, z, h, 1, 0, 1); }                                                // ENTITY::_SET_ENTITY_COORDS_AND_HEADING (as short_update's func_1610)
    static inline bool PlaceOnGround(int e)  { return Invoke<int>(0x9587913B9E772D29ULL, e, 0) != 0; }            // ENTITY::PLACE_ENTITY_ON_GROUND_PROPERLY
    static inline void FreezePosition(int e, int on) { InvokeVoid(0x7D9EFB7AD6B19754ULL, e, on); }               // ENTITY::FREEZE_ENTITY_POSITION
    static inline bool CanBeDamaged(int e)           { return Invoke<int>(0x75DF9E73F2F005FDULL, e) != 0; }      // ENTITY::_GET_ENTITY_CAN_BE_DAMAGED
    static inline void SetCanBeDamaged(int e, int on) { InvokeVoid(0x0D06D522B90E861FULL, e, on); }              // ENTITY::SET_ENTITY_CAN_BE_DAMAGED
    static inline bool IsPedFalling(int p)           { return Invoke<int>(0xFB92A102F1C4DFA3ULL, p) != 0; }      // PED::IS_PED_FALLING
    static inline Vec3 OffsetInWorld(int e, float x, float y, float z)
    { return Invoke<Vec3>(0x1899F328B0E12848ULL, e, x, y, z); }                                                   // ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS
    static inline bool CanPedBeMounted(int m)        { return Invoke<int>(0x2D64376CF437363EULL, m) != 0; }      // PED::CAN_PED_BE_MOUNTED
    static inline int  GetMount(int p)               { return Invoke<int>(0xE7E11B8DCBED1058ULL, p); }            // PED::GET_MOUNT
    static inline void SetPedOntoMount(int p, int m) { InvokeVoid(0x028F76B6E78246EBULL, p, m, -1, 1); }         // PED::SET_PED_ONTO_MOUNT(ped, mount, seat, p3)
    static inline void SetPedCanBeTargetted(int p, int on) { InvokeVoid(0x63F58F7C80513AADULL, p, on); }         // PED::SET_PED_CAN_BE_TARGETTED
    static inline void SetGameplayCamRelativeHeading(float h) { InvokeVoid(0x5D1EB123EAC5D071ULL, h, 1.0f); }    // CAMERA::SET_GAMEPLAY_CAM_RELATIVE_HEADING
    static inline bool IsPedUsingScenarioHash(int p, uint32_t h) { return Invoke<int>(0x34D6AC1157C8226CULL, p, h) != 0; } // PED::IS_PED_USING_SCENARIO_HASH
    static inline void UnhitchHorse(int h)           { InvokeVoid(0x0348469DAA17576CULL, h); }                    // PHYSICS::_UNHITCH_HORSE
    // ...and the clock
    static inline void AddToClockTime(int h, int m, int s) { InvokeVoid(0xAB7C251C7701D336ULL, h, m, s); }       // CLOCK::ADD_TO_CLOCK_TIME
    static inline int  ClockHours()                  { return Invoke<int>(0xC82CF208C2B19199ULL); }               // CLOCK::GET_CLOCK_HOURS
    static inline int  ClockMinutes()                { return Invoke<int>(0x4E162231B823DBBFULL); }               // CLOCK::GET_CLOCK_MINUTES

    // Horse bonding and whistle range (short_update's func_511)
    static inline int   DefaultMaxAttributeRank(uint32_t m, int attr)      { return Invoke<int>(0x7C059C55AD940CB4ULL, m, attr); }       // ATTRIBUTE::GET_DEFAULT_MAX_ATTRIBUTE_RANK
    static inline int   PointsNeededForRank(uint32_t m, int attr, int r)   { return Invoke<int>(0x94A7F191DB49A44DULL, m, attr, r); }   // ATTRIBUTE::GET_DEFAULT_ATTRIBUTE_POINTS_NEEDED_FOR_RANK
    static inline float WhistleRangeMin(int level)                         { return Invoke<float>(0xEB67D4E056C85A81ULL, level); }      // TASK::_GET_WHISTLE_RANGE_MIN_FOR_BONDING_LEVEL
    static inline float WhistleRangeMax(int level)                         { return Invoke<float>(0x78D8C1D4EB80C588ULL, level); }      // TASK::_GET_WHISTLE_RANGE_MAX_FOR_BONDING_LEVEL
}

static void DrawTextLine(const char* text, float x, float y, float scale, int r, int g, int b)
{
    // Drop shadow first, then the text, for readability on bright scenes.
    N::BgSetTextScale(scale, scale);
    N::BgSetTextColor(0, 0, 0, 200);
    N::BgDisplayText(N::VarStringLiteral(text), x + 0.0012f, y + 0.0018f);
    N::BgSetTextScale(scale, scale);
    N::BgSetTextColor(r, g, b, 255);
    N::BgDisplayText(N::VarStringLiteral(text), x, y);
}

// ===========================================================================
// The game's script globals (game build 1491.50)
// ===========================================================================
//
// Indices come from the decompiled scripts of build 1491.50. A struct field is
// base + offset; an array element is base + 1 + index * size (slot 0 holds the
// array's length). Values are 32-bit ints in 8-byte slots.

namespace G
{
    static const int kPlayerPed   = 35;       // Global_35: the player's ped (every script caches it here)
    static const int kFtFlags     = 43907;    // Global_43907: fast travel requests between the camp scripts and short_update
    static const int kFtState     = 43908;    // Global_43908: short_update's fast travel state
    static const int kCampFlags   = 1392040;  // Global_1392040: camp flags; bit 23 = at a campfire, camp actions allowed
    static const int kUiBusy      = 1898068;  // Global_1898068 and .f_4: a game menu is up (the camp checks both)
    static const int kUiBusy4     = 1898072;
    static const int kActiveHorse = 1135;     // Global_40.f_1095: slot of the active horse (0-6, -1 = none)
    static const int kHorseSaves  = 1136;     // Global_40.f_1095.f_1[slot /*436*/]: saved horse data
    static const int kHorsePeds   = 1900383;  // Global_1900383[slot /*45*/]: the horse peds
    static const int kLodging     = 4644;     // Global_40.f_4283.f_321: lodging upgrade level (3+ = fast travel map)
    static const int kSession     = 1572899;  // Global_1572887.f_12: -1 in Story Mode
    static const int kUnlockFlow  = 1351050;  // Global_1347702[68 /*49*/].f_15: the flow behind the other unlock (func_339(68))
    static const int kFlowStatus  = 12106;    // Global_12106[flow /*7*/].f_1: flow status, 5 or 6 = done
    static const int kKneelHud    = 1955831;  // Global_1955830.f_1: bit 2 = the kneel's prompts are up (bits 2+3: a campfire's)
    static const int kMenuStopA   = 1357517;  // Global_1357517: short_update closes the menu while set (func_503)
    static const int kMenuStopB   = 1935690;  // Global_1935689.f_1: likewise (func_504)

    // Set Up Camp: dynamic_craft_scenario's func_21 (where the game lets you camp), its Set Up
    // Camp button, and player_camp.
    static const int kPromptList  = 1945188;  // Global_1945188[slot /*18*/]: prompts made through the scripts' shared helper
                                              //   (f_1 bit 2 in use, f_3 the prompt, f_4 its control, f_16 the script's thread)
    static const int kCampFlags2  = 1392041;  // Global_1392040.f_1: bit 0 = a script has camping blocked (unless bit 9)
    static const int kCampIsUp    = 9459;     // Global_40.f_9419: bit 23 = "The camp has already been set up"
    static const int kZone        = 1894899;  // Global_1894899: bit 2 = in a gang hideout
    static const int kZoneArea    = 1894901;  // Global_1894899.f_2: the area you're in (-1 = none)
    static const int kAreaFlags   = 23118;    // Global_23118[area /*11*/]: bit 25 = the area is under lockdown
    static const int kDistrict    = 1897993;  // Global_1897952.f_41: the district you're in (8 = Guarma)
    static const int kStoryCamp   = 1359044;  // Global_1357549.f_1495: bit 9 = at the gang's camp or Beecher's Hope
    static const int kLaw         = 1935630;  // Global_1935630: the law's pursuit (f_13, f_17 to f_21)
    static const int kOnMission   = 1898328;  // Global_1898164.f_164: on a mission (short_update works it out each frame)
    static const int kMissionCamp = 1914318;  // Global_1914296.f_22: bit 0 = the mission lets you camp
    static const int kEncounter   = 1326827;  // Global_1310750.f_16077: the thread of a random encounter under way
    static const int kAmbush      = 1393449;  // Global_1393447.f_2: bit 4 = an ambush under way
    static const int kHorseAway   = 4190;     // Global_40.f_1095.f_3054.f_1: set while the active horse is away
    static const int kLedHorse    = 1900776;  // Global_1900383.f_393: a horse you're leading
    static const int kCampState   = 43885;    // Global_43885: player_camp's state (14 = it gave up)
    static const int kCampFlow120 = 1353598;  // Global_1347702[120 /*49*/].f_15: a flow whose mission has its own camp spot
    static const int kCampFlow15  = 1836123;  // Global_1835011[15 /*74*/].f_1: likewise
    static const int kItemUseOff  = 1935697;  // Global_1935689.f_8: item use held (bait being laid): the button uses no kit then
    static const int kCampForced  = 1392042;  // Global_1392040.f_2: a camp the game sets up itself: a disabled kit still works
    static const int kInvFlagA    = 1931689;  // Global_1914319.f_17370 \ the third argument the game passes when it
    static const int kInvFlagB    = 1933316;  // Global_1914319.f_18996.f_1 / asks whether the kit is disabled (func_168(0))
    static const int kEvelynSpot  = 1351353;  // Global_1347702[74 /*49*/].f_24: the spot where RCM_EVELYN_MILLER4 bans camping (12 m)
    // Waypoint travel
    static const int kSniperOff   = 1934322;  // Global_1934266.f_56: set = medium_update's New Austin sniper is off (its func_367)

    // Bits of kFtFlags (short_update func_80)
    static const int FT_MUSIC  = 1;   // play the fast travel music
    static const int FT_OPEN   = 4;   // open the fast travel menu
    static const int FT_CHOSEN = 8;   // set by short_update: a place was chosen
    static const int FT_CLOSE  = 16;  // close the menu
    static const int FT_READY  = 32;  // the camp has packed up: go
    // (64 is short_update's own note that it faded the screen during the camp's
    // kick-the-fire animation; this plugin fades the screen itself.)

    static const int CAMP_AT_FIRE = 1 << 23;

    static inline uint64_t* Ptr(int idx)
    {
        return SH_getGlobalPtr ? SH_getGlobalPtr(idx) : nullptr;
    }

    static inline bool Get(int idx, int32_t* out)
    {
        uint64_t* p = Ptr(idx);
        if (!p)
            return false;
        memcpy(out, p, 4);
        return true;
    }

    static inline int Int(int idx, int fallback)
    {
        int32_t v;
        return Get(idx, &v) ? v : fallback;
    }

    static inline float Float(int idx, float fallback)
    {
        uint64_t* p = Ptr(idx);
        if (!p)
            return fallback;
        float f;
        memcpy(&f, p, 4);
        return f;
    }

    static inline bool Set(int idx, int32_t v)
    {
        uint64_t* p = Ptr(idx);
        if (!p)
            return false;
        memcpy(p, &v, 4);
        return true;
    }
}

// ===========================================================================
// Hashes
// ===========================================================================

static const int kRestGroup = 342152817; // the kneel menu's prompt group ("REST_UI_GROUP")

static uint32_t H_DYNAMIC_CRAFT, H_SHORT_UPDATE, H_CAMERA_ITEM, H_SIMPLE_CRAFTING, H_JOURNAL;
static uint32_t H_PLAYER_CAMP, H_INTERACTIVE_CAMPFIRE, H_PROPERTY_USE, H_CAMPFIRE_ALWAYS, H_SLEEPING;
static uint32_t H_FAST_TRAVEL_MENU, H_PLAYER_MENU;
static uint32_t H_INPUT_CONTEXT_X, H_INPUT_CONTEXT_Y, H_INPUT_CONTEXT_B, H_INPUT_JUMP;
static uint32_t H_KIT_CAMP, H_KIT_CAMP_SIMPLE, H_RCM_EVELYN4, H_LAW_DISPATCH_PENDING;
static uint32_t H_INPUT_MOVE_LR, H_INPUT_MOVE_UD, H_FRONTEND_PAUSE, H_FRONTEND_PAUSE_ALT, H_CTX_FRONTEND_MENU;
static uint32_t H_KNEEL_EXIT;
static uint32_t H_PLAYER_ZERO, H_BLACKWATER, H_GAPTOOTH_RIDGE, H_RIO_BRAVO, H_CHOLLA_SPRINGS, H_HENNIGANS_STEAD;

static void InitHashes()
{
    H_DYNAMIC_CRAFT    = Joaat("dynamic_craft_scenario");
    H_SHORT_UPDATE     = Joaat("short_update");
    H_CAMERA_ITEM      = Joaat("CAMERA_ITEM");
    H_SIMPLE_CRAFTING  = Joaat("SIMPLE_CRAFTING");
    H_JOURNAL          = Joaat("DOC_PLAYER_JOURNAL");
    H_PLAYER_CAMP      = Joaat("player_camp");
    H_INTERACTIVE_CAMPFIRE = Joaat("interactive_campfire");
    H_PROPERTY_USE     = Joaat("property_use_core");
    H_CAMPFIRE_ALWAYS  = Joaat("campfire_always");
    H_SLEEPING         = Joaat("sleeping_scenario");
    H_FAST_TRAVEL_MENU = Joaat("FAST_TRAVEL_MENU");
    H_PLAYER_MENU      = Joaat("PLAYER_MENU");
    H_INPUT_CONTEXT_X  = Joaat("INPUT_CONTEXT_X");
    H_INPUT_CONTEXT_Y  = Joaat("INPUT_CONTEXT_Y");
    H_INPUT_CONTEXT_B  = Joaat("INPUT_CONTEXT_B");
    H_KIT_CAMP         = Joaat("KIT_CAMP");
    H_KIT_CAMP_SIMPLE  = Joaat("KIT_CAMP_SIMPLE");
    H_RCM_EVELYN4      = Joaat("RCM_EVELYN_MILLER4");
    H_LAW_DISPATCH_PENDING = Joaat("LAW_DISPATCH_PENDING");
    H_INPUT_JUMP       = Joaat("INPUT_JUMP");
    H_INPUT_MOVE_LR    = Joaat("INPUT_MOVE_LR");
    H_INPUT_MOVE_UD    = Joaat("INPUT_MOVE_UD");
    H_FRONTEND_PAUSE   = Joaat("INPUT_FRONTEND_PAUSE");
    H_FRONTEND_PAUSE_ALT = Joaat("INPUT_FRONTEND_PAUSE_ALTERNATE");
    H_CTX_FRONTEND_MENU  = Joaat("FrontendMenu");
    H_KNEEL_EXIT       = Joaat("DYNAMIC_KNEEL_SLOW_EXIT");
    H_PLAYER_ZERO      = Joaat("PLAYER_ZERO");      // Arthur
    H_BLACKWATER       = Joaat("BLACKWATER");       // the town (map zone type 1)
    H_GAPTOOTH_RIDGE   = Joaat("GAPTOOTHRIDGE");    // New Austin's districts (type 10), medium_update's 13 to 16
    H_RIO_BRAVO        = Joaat("RIOBRAVO");
    H_CHOLLA_SPRINGS   = Joaat("CHOLLASPRINGS");
    H_HENNIGANS_STEAD  = Joaat("HENNIGANSSTEAD");
}

// ===========================================================================
// The game's texts: the CAMP text block
// ===========================================================================
//
// The campfire's texts (the Fast Travel prompt CAMP_FT_PROMPT, the horse and
// region messages, the fast travel menu's heading) live in the game's CAMP
// text block. Only the camp scripts load it (player_camp, interactive_campfire,
// property_use_core, campfire_always, each unloading it when it's done; and
// long_update, again and again while a campfire you left is still burning),
// and the kneel menu's own Craft menu (simple_crafting) loads it when it opens
// and unloads it when it closes. A prompt whose label isn't loaded has no
// text, and the game doesn't draw it, although its button still works. So the
// plugin
//   * asks for CAMP as soon as a kneel starts, and lets it go again once the
//     kneel is over, if the plugin loaded it and nothing else is using it (as
//     simple_crafting does);
//   * uses the label only while it's loaded, and otherwise the same words as
//     plain text: the game's own, read from the label while it was loaded, or
//     English until then.

static const char kCampText[]  = "CAMP";
static const char kFtLabel[]   = "CAMP_FT_PROMPT";   // "Fast Travel"
static const char kFtEnglish[] = "Fast Travel";

static bool g_campTextOurs      = false;  // the plugin loaded it
static int  g_campTextAskedAt   = -1;     // when the plugin last asked for it
static bool g_campTextSeen      = false;  // seen loaded since then
static int  g_campTextHoldUntil = 0;      // a help text with a CAMP label is on screen until then
static char g_ftText[64]        = "";     // the game's own words for CAMP_FT_PROMPT, in its language

static bool CampTextLoaded()
{
    return N::TextBlockIsLoaded(kCampText);
}

// A label from the CAMP text can be shown right now.
static bool CampLabelReady(const char* label)
{
    return CampTextLoaded() && N::DoesTextLabelExist(label);
}

static void RequestCampText(int now)
{
    if (CampTextLoaded())
    {
        g_campTextSeen = true;
        return;
    }
    if (!N::DoesTextBlockExist(kCampText))
        return;
    // Asked again at once if it was loaded and has gone since (the Craft menu
    // unloads it); while a request is still loading, every 1.5 s at most.
    if (g_campTextAskedAt < 0 || g_campTextSeen || now - g_campTextAskedAt > 1500)
    {
        N::TextBlockRequest(kCampText);
        if (g_campTextAskedAt < 0)
            Log("Loading the game's CAMP text (the \"Fast Travel\" label).");
        g_campTextAskedAt = now;
        g_campTextSeen = false;
        g_campTextOurs = true;
    }
}

static void ReleaseCampText(int now)
{
    if (!g_campTextOurs || now - g_campTextHoldUntil < 0)
        return;
    // Something else is using it now. The camp scripts and the Craft menu
    // unload it themselves when they're done.
    if (N::ScriptThreads(H_PLAYER_CAMP) > 0 || N::ScriptThreads(H_INTERACTIVE_CAMPFIRE) > 0 ||
        N::ScriptThreads(H_PROPERTY_USE) > 0 || N::ScriptThreads(H_CAMPFIRE_ALWAYS) > 0 ||
        N::ScriptThreads(H_SIMPLE_CRAFTING) > 0 || N::ScriptThreads(H_SLEEPING) > 0)
        return;
    if (CampTextLoaded())
    {
        N::TextBlockDelete(kCampText);
        if (g_cfg.debugLog)
            Log("Unloaded the CAMP text again.");
    }
    else if (!g_campTextSeen && g_campTextAskedAt >= 0 && now - g_campTextAskedAt < 10000)
        return;   // the request is still loading: unload it once it's in, rather than leave it behind
    g_campTextOurs = false;
    g_campTextAskedAt = -1;
    g_campTextSeen = false;
}

// Keep the game's own words for "Fast Travel", in the game's language
// (call while CampLabelReady(kFtLabel)). False if they couldn't be read.
static bool ReadFtText()
{
    const char* s = N::LabelText(kFtLabel);
    if (!s || !s[0] || strlen(s) >= sizeof g_ftText || strcmp(s, "NULL") == 0 || strcmp(s, kFtLabel) == 0)
        return false;
    if (strcmp(s, g_ftText) != 0)
    {
        snprintf(g_ftText, sizeof g_ftText, "%s", s);
        Log("The game's text for Fast Travel: \"%s\".", g_ftText);
    }
    return true;
}

// ===========================================================================
// On-screen messages
// ===========================================================================

static char      g_noteText[256];
static ULONGLONG g_noteUntil = 0;
static int       g_noteR = 255, g_noteG = 230, g_noteB = 160;

static void Notify(int ms, bool warning, const char* fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_noteText, sizeof g_noteText, fmt, ap);
    va_end(ap);
    g_noteUntil = GetTickCount64() + (ULONGLONG)ms;
    g_noteR = 255;
    g_noteG = warning ? 140 : 230;
    g_noteB = warning ? 110 : 160;
}

static void DrawNotification()
{
    if (GetTickCount64() < g_noteUntil)
        DrawTextLine(g_noteText, 0.015f, 0.015f, 0.38f, g_noteR, g_noteG, g_noteB);
}

// The game's help box (top left), as the camp scripts post it (their func_58):
// a duration struct and a text struct whose second field is the text, either a
// text label from the game (shown in the game's language) or a VAR_STRING.
// label is one of the CAMP text's, used only while it's loaded; otherwise the
// same words go in as plain English text.
static void HelpText(const char* label, const char* literal)
{
    int64_t data[4] = { 8000, 0, 0, 0 };
    int64_t text[2] = { 0, 0 };
    bool useLabel = label && CampLabelReady(label);
    const char* s = useLabel ? label : N::VarStringLiteral(literal);
    text[1] = (int64_t)(intptr_t)s;
    N::PostHelpText(data, text, 1);
    if (useLabel)
        g_campTextHoldUntil = N::GameTimer() + 8500;   // keep the text loaded while it's on screen
    Log("Help text: %s%s", useLabel ? label : literal, (label && !useLabel) ? " (label not loaded)" : "");
}

// ===========================================================================
// Why fast travel isn't available right now
// ===========================================================================

enum Reason
{
    R_OK = 0,
    R_BROKEN,      // the game's fast travel didn't respond earlier: off for this session
    R_UNSUPPORTED, // the script globals don't look like game build 1491.50
    R_NOT_READY,   // short_update isn't running
    R_NO_SCENARIO, // the kneel isn't a scenario task short_update accepts (its func_502)
    R_BUSY,        // a fast travel is already under way, or a game menu is up
    R_LOCKED,      // fast travel isn't unlocked yet
    R_MISSION,
    R_WANTED,
    R_HORSE_DEAD,
    R_HORSE_FAR,
    R_NO_HORSE,
    R_VEHICLE,
};

static const char* ReasonName(int r)
{
    switch (r)
    {
    case R_OK:         return "available";
    case R_BROKEN:     return "turned off: the game's fast travel didn't respond earlier";
    case R_UNSUPPORTED: return "off: the game's script globals don't match game build 1491.50";
    case R_NOT_READY:  return "the game's fast travel script isn't running";
    case R_NO_SCENARIO: return "the kneel isn't a scenario task the game's fast travel menu accepts (PED_HAS_USE_SCENARIO_TASK is false)";
    case R_BUSY:       return "busy (a fast travel or a game menu is under way)";
    case R_LOCKED:     return "fast travel isn't unlocked yet";
    case R_MISSION:    return "on a mission";
    case R_WANTED:     return "wanted";
    case R_HORSE_DEAD: return "horse is dead";
    case R_HORSE_FAR:  return "horse is too far away";
    case R_NO_HORSE:   return "no horse";
    case R_VEHICLE:    return "in a vehicle or on a train";
    }
    return "?";
}

static char g_brokenWhy[200];

static void ShowReason(int r)
{
    switch (r)
    {
    case R_HORSE_DEAD: HelpText("DEAD_HORSE_FT", "You can't fast travel as your horse is dead."); break;
    case R_HORSE_FAR:  HelpText("FAR_HORSE_FT", "Your horse is too far away to fast travel."); break;
    case R_NO_HORSE:   HelpText("NO_HORSE_FT", "You can't fast travel without your horse."); break;
    case R_LOCKED:
        HelpText(nullptr, "You haven't unlocked fast travel yet. It opens up the same way as at your camp "
                          "(for Arthur: the lodging upgrade in the camp ledger).");
        break;
    case R_MISSION:    HelpText(nullptr, "You can't fast travel during a mission."); break;
    case R_WANTED:     HelpText(nullptr, "You can't fast travel while you're wanted."); break;
    case R_BROKEN:     HelpText(nullptr, g_brokenWhy[0] ? g_brokenWhy :
                                "Fast Travel Anywhere is off for now. See FastTravelAnywhere.log."); break;
    case R_UNSUPPORTED:
        HelpText(nullptr, "Fast Travel Anywhere doesn't recognise this version of the game, so it stays off. "
                          "See FastTravelAnywhere.log.");
        break;
    case R_NOT_READY:
    case R_NO_SCENARIO:
    case R_BUSY:
    case R_VEHICLE:
    default:           HelpText(nullptr, "You can't fast travel right now."); break;
    }
}

// ===========================================================================
// Game checks
// ===========================================================================

static bool g_globalsOk      = false;

// Before the plugin ever writes a global, check that this game build lays them
// out as build 1491.50 does: Global_35 must be the player, and the fast travel
// globals must hold the small values short_update keeps there.
static bool CheckGlobals(int ped, char* why, size_t whySize)
{
    if (!SH_getGlobalPtr)
    {
        snprintf(why, whySize, "Script Hook has no getGlobalPtr");
        return false;
    }
    int32_t player = 0, st = 0, fl = 0, camp = 0;
    if (!G::Get(G::kPlayerPed, &player) || !G::Get(G::kFtState, &st) ||
        !G::Get(G::kFtFlags, &fl) || !G::Get(G::kCampFlags, &camp))
    {
        snprintf(why, whySize, "Script Hook returned no pointer for a script global");
        return false;
    }
    if (player != ped)
    {
        snprintf(why, whySize, "Global_35 is %d, not the player (%d): a different game build?", player, ped);
        return false;
    }
    if (st < 0 || st > 6 || fl < 0 || fl > 127)
    {
        snprintf(why, whySize, "unexpected values (fast travel state %d, flags %d, camp flags 0x%X): "
                 "a different game build?", st, fl, (unsigned)camp);
        return false;
    }
    return true;
}

// Fast travel unlocked, as the camp decides it (player_camp func_105):
// the lodging upgrade at level 3 or more, or (outside it) flow 68 done.
// Returns 1 yes, 0 no, -1 can't tell (treated as yes).
static int FastTravelUnlocked(int* lodgingOut, int* flowStatusOut)
{
    int lodging = G::Int(G::kLodging, -999);
    *lodgingOut = lodging;
    *flowStatusOut = -1;
    if (lodging >= 3 && lodging <= 20)
        return 1;
    if (G::Int(G::kSession, 0) == -1)
    {
        int flow = G::Int(G::kUnlockFlow, 0);
        if (flow > 0 && flow < 771)
        {
            int status = G::Int(G::kFlowStatus + 1 + flow * 7 + 1, -1);
            *flowStatusOut = status;
            if (status == 5 || status == 6)
                return 1;
        }
    }
    if (lodging < 0 || lodging > 20)
        return -1;
    return 0;
}

// The horses short_update can take along: the active one (slot from
// Global_40.f_1095) and slot 1. Global_1900383[slot] holds the ped.
struct HorseInfo
{
    int   slot;     // -1 = none
    int   ped;      // 0 = none
    bool  exists, dead;
    float dist, range;
};

static float Lerp(float a, float b, float t) { return (1.0f - t) * a + t * b; }

// The horse's whistle range, exactly as short_update's func_511 works it out
// from the save data for the slot: the bonding level's min..max range, by
// progress toward the next level (7 = the bonding attribute). -1 when the
// saved model isn't valid: the game then counts the horse as too far away and
// travels without it.
static float WhistleRange(int slot)
{
    int base = G::kHorseSaves + 1 + slot * 436;
    uint32_t model = (uint32_t)G::Int(base + 9, 0);
    int      level = G::Int(base + 372, -1);
    float    pts   = G::Float(base + 373, 0.0f);

    if (!N::IsModelValid(model))
        return -1.0f;
    int   maxRank = N::DefaultMaxAttributeRank(model, 7);
    float rmin    = N::WhistleRangeMin(level);
    float rmax    = N::WhistleRangeMax(level);
    if (level >= maxRank)
        return rmin;
    float need0 = (float)N::PointsNeededForRank(model, 7, level);
    float need1 = (float)N::PointsNeededForRank(model, 7, level + 1);
    if (need1 == need0)
        return rmin;
    return Lerp(rmin, rmax, (pts - need0) / (need1 - need0));
}

static HorseInfo ReadHorse(int slot, const N::Vec3& me)
{
    HorseInfo h;
    memset(&h, 0, sizeof h);
    h.slot = slot;
    h.range = -1.0f;
    if (slot < 0 || slot > 6)
        return h;
    h.ped = G::Int(G::kHorsePeds + 1 + slot * 45, 0);
    // short_update only takes an animal along (func_1595: not IS_PED_HUMAN).
    if (!h.ped || !N::DoesEntityExist(h.ped) || !N::IsEntityAPed(h.ped) || N::IsPedHuman(h.ped))
    {
        h.ped = 0;
        return h;
    }
    h.exists = true;
    h.dead   = N::IsEntityDead(h.ped) || N::IsPedInWrithe(h.ped);   // what short_update checks
    N::Vec3 p = N::EntityCoords(h.ped);
    float dx = p.x - me.x, dy = p.y - me.y;   // short_update measures flat (func_510)
    h.dist  = sqrtf(dx * dx + dy * dy);
    h.range = WhistleRange(slot);
    return h;
}

static int HorseCheck(int ped, HorseInfo* activeOut, HorseInfo* slot1Out)
{
    N::Vec3 me = N::EntityCoords(ped);
    HorseInfo a = ReadHorse(G::Int(G::kActiveHorse, -1), me);
    HorseInfo b = ReadHorse(1, me);
    if (activeOut) *activeOut = a;
    if (slot1Out)  *slot1Out = b;

    bool aliveA = a.exists && !a.dead, aliveB = b.exists && !b.dead;
    bool nearA  = aliveA && a.range >= 0.0f && a.dist <= a.range;
    bool nearB  = aliveB && b.range >= 0.0f && b.dist <= b.range;

    if (g_cfg.requireHorseNearby ? (nearA || nearB) : (aliveA || aliveB))
        return R_OK;
    // The messages, in the order the game checks them (property_use_core func_198).
    if (a.exists)
        return a.dead ? R_HORSE_DEAD : R_HORSE_FAR;
    if (b.exists)
        return b.dead ? R_HORSE_DEAD : R_HORSE_FAR;
    return R_NO_HORSE;
}

// Arthur is all the way down in the kneel: what short_update needs to keep its
// menu open (func_502(1): in the scenario's base, or active in the scenario).
static bool FullyKneeling(int ped)
{
    return N::IsPedActiveInScenario(ped) || N::PedIsInScenarioBase(ped);
}

// Everything a campfire checks before it offers Fast Travel (player_camp
// func_105 and func_306), in the order the reasons are reported. For a trip
// to the waypoint (waypoint = true) the same rules apply, except those that
// are only about the game's fast travel menu (short_update must be running,
// with the kneel as a use-scenario task, and the menu app able to launch).
static int Availability(int ped, int player, bool waypoint)
{
    if (!waypoint && g_brokenWhy[0])
        return R_BROKEN;
    if (!g_globalsOk)
        return R_UNSUPPORTED;
    if (!waypoint && N::ScriptThreads(H_SHORT_UPDATE) <= 0)
        return R_NOT_READY;
    int st = G::Int(G::kFtState, -1), fl = G::Int(G::kFtFlags, -1);
    if (st != 0 || fl < 0 || (fl & (G::FT_OPEN | G::FT_CHOSEN | G::FT_READY)) != 0)
        return R_BUSY;
    if (g_cfg.requireUnlock)
    {
        int lodging, flow;
        if (FastTravelUnlocked(&lodging, &flow) == 0)
            return R_LOCKED;
    }
    if (!g_cfg.allowOnMissions && N::MissionFlag())
        return R_MISSION;
    if (!g_cfg.allowWhenWanted && N::IsLawIncidentActive(player))
        return R_WANTED;
    if (N::IsPedInAnyVehicle(ped) || N::IsPedInAnyTrain(ped) || N::IsPedOnMount(ped))
        return R_VEHICLE;
    // short_update would close the menu straight away (func_502). The kneel is a
    // use-scenario task from its first frame (dynamic_craft_scenario ends as
    // soon as the player isn't using a scenario); being all the way down, the
    // other half of func_502, is what a press waits for.
    if (!waypoint && !N::PedHasUseScenarioTask(ped))
        return R_NO_SCENARIO;
    // The game's menu needs a living horse even with RequireHorseNearby=0
    // (short_update closes it without one); a trip to the waypoint doesn't.
    if (!waypoint || g_cfg.requireHorseNearby)
    {
        int horse = HorseCheck(ped, nullptr, nullptr);
        if (horse != R_OK)
            return horse;
    }
    // A game menu is up, or short_update would close the menu (func_503, func_504).
    if (N::IsUiAppActive(H_PLAYER_MENU) || G::Int(G::kUiBusy, 0) != 0 || G::Int(G::kUiBusy4, 0) != 0 ||
        G::Int(G::kMenuStopA, 0) != 0 || G::Int(G::kMenuStopB, 0) != 0 ||
        (!waypoint && !N::CanLaunchUiApp(H_FAST_TRAVEL_MENU)))
        return R_BUSY;
    return R_OK;
}

// The kneel menu is up. dynamic_craft_scenario shows its "Resting" prompts as
// soon as the kneel animation's event fires, before Arthur is all the way down
// (its func_6, state 1 -> 2), and marks that with bit 2 of Global_1955830.f_1
// (the campfire scripts set bits 2 and 3 for their own prompts; the kneel
// clears 3). It clears bit 2 again when it takes its prompts down for the
// Craft menu, the journal, Set Up Camp and the like, though not for an
// interaction target or the camera (checked below). Should the bit never show
// in a kneel (a game build with the globals elsewhere), fully kneeling counts,
// as in 1.0.0.
static bool g_kneelHudSeen = false;   // bit 2 seen in this kneel

static bool KneelMenuUp(int ped, int player)
{
    if (N::ScriptThreads(H_DYNAMIC_CRAFT) <= 0)
        return false;
    if (N::IsEntityDead(ped))
        return false;
    int hud = G::Int(G::kKneelHud, 0);
    if (hud & 4)
        g_kneelHudSeen = true;
    bool kneelBit  = (hud & 4) != 0 && (hud & 8) == 0;
    bool promptsUp = kneelBit || (!g_kneelHudSeen && N::IsPedActiveInScenario(ped));
    if (!promptsUp || N::IsPedExitingScenario(ped))
        return false;
    if (N::PlayerHasInteractionTarget(player))
        return false;
    if (N::ScriptThreads(H_CAMERA_ITEM) > 0 || N::ScriptThreads(H_SIMPLE_CRAFTING) > 0 ||
        N::ScriptThreads(H_JOURNAL) > 0)
        return false;
    if (N::IsPedRunningItemInteraction(ped))
        return false;
    return true;
}

// ===========================================================================
// The Fast Travel prompt
// ===========================================================================

// What the prompt's text is.
enum PromptTextKind
{
    PT_CUSTOM,   // PromptText from the .ini
    PT_LABEL,    // the game's label CAMP_FT_PROMPT (needs the CAMP text loaded)
    PT_LITERAL,  // the game's own words for it, read from the label earlier, as plain text
    PT_ENGLISH,  // "Fast Travel" in English, until the game's own words can be read
};

static int      g_prompt        = 0;
static int      g_promptEnabled = -1;
static int      g_promptKind    = PT_LABEL;
static uint32_t g_control       = 0;   // the control the prompt uses (PromptControl, checked)

static void DeletePrompt()
{
    if (g_prompt)
    {
        if (N::PromptIsValid(g_prompt))
            N::PromptDelete(g_prompt);
        g_prompt = 0;
    }
    g_promptEnabled = -1;
}

static void DeleteCampPrompt();   // the Set Up Camp prompt (see "Set Up Camp anywhere")

// Built the way the game builds a campfire's Fast Travel prompt (player_camp
// func_158 -> func_53, mode 2: a tap that fires on release), with the priority
// the kneel menu gives its own prompts (1), then put in the kneel menu's group
// (dynamic_craft_scenario func_20). Its text: PromptText if set, else the
// campfire's own label while the CAMP text is loaded, else the same words as
// plain text.
static void CreatePrompt()
{
    uint32_t control = g_cfg.promptControl;
    uint32_t space   = Joaat("INPUT_CONTEXT_A");
    if (control != space && !N::IsControlActionValid(control))
    {
        Log("PromptControl %s (0x%08X) isn't a control the game knows; using INPUT_CONTEXT_A.",
            g_cfg.promptControlName, control);
        control = space;
    }
    g_control = control;

    const char* text;
    const char* how;
    if (g_cfg.promptText[0])
    {
        g_promptKind = PT_CUSTOM;
        text = N::VarStringLiteral(g_cfg.promptText);
        how  = "PromptText";
    }
    else if (CampLabelReady(kFtLabel))
    {
        ReadFtText();
        g_promptKind = PT_LABEL;
        text = kFtLabel;
        how  = "the game's label";
    }
    else if (g_ftText[0])
    {
        g_promptKind = PT_LITERAL;
        text = N::VarStringLiteral(g_ftText);
        how  = "the game's text, its label isn't loaded";
    }
    else
    {
        g_promptKind = PT_ENGLISH;
        text = N::VarStringLiteral(kFtEnglish);
        how  = "English text, the game's label isn't loaded yet";
    }

    int p = N::PromptRegisterBegin();
    N::PromptSetControlAction(p, control);
    N::PromptSetText(p, text);
    N::PromptSetPriority(p, 1);
    N::PromptSetTransportMode(p, 0);
    N::PromptSetAttribute(p, 18, 1);
    N::PromptSetStandardMode(p, 1);
    N::PromptRegisterEnd(p);
    N::PromptSetGroup(p, kRestGroup, 0);
    N::PromptSetVisible(p, 1);
    N::PromptSetEnabled(p, 1);
    g_prompt = p;
    g_promptEnabled = 1;
    Log("Fast Travel added to the kneel menu (%s).", how);
}

// Keep the prompt's text showing (once per frame while it's up). Should the
// CAMP text be unloaded under it (any script can), the same prompt comes back
// with its words as plain text. And English stands in only until the game's
// own words can be read.
static void CheckPromptText()
{
    if (!g_prompt || !N::PromptIsValid(g_prompt))
        return;
    if (g_promptKind == PT_LABEL && !CampLabelReady(kFtLabel))
    {
        Log("The CAMP text was unloaded: Fast Travel now shows its text without the label.");
        DeletePrompt();
    }
    else if (g_promptKind == PT_ENGLISH && CampLabelReady(kFtLabel))
    {
        if (ReadFtText() && strcmp(g_ftText, kFtEnglish) == 0)
            g_promptKind = PT_LITERAL;    // the same words: nothing to change
        else
            DeletePrompt();               // back right away with the game's label
    }
}

// ===========================================================================
// Fast travel, step by step
// ===========================================================================

enum Phase
{
    PH_IDLE,       // kneel menu watch, prompt
    PH_REQUESTED,  // asked short_update to open the menu (bit 4)
    PH_MENU,       // the game's fast travel menu is open
    PH_FADING,     // a place was chosen: standing up, fading out
    PH_TRAVEL,     // told the game to go (bit 32), it's travelling
    PH_ARRIVED,    // trip over: make sure the screen comes back
};

static const char* PhaseName(int p)
{
    switch (p)
    {
    case PH_IDLE:      return "idle";
    case PH_REQUESTED: return "menu requested";
    case PH_MENU:      return "menu open";
    case PH_FADING:    return "fading out";
    case PH_TRAVEL:    return "travelling";
    case PH_ARRIVED:   return "arrived";
    }
    return "?";
}

static int  g_phase          = PH_IDLE;
static int  g_phaseStart     = 0;
static bool g_weSetCampBit   = false;
static int  g_menuSeenAt     = 0;     // last time the menu app was seen open
static int  g_menuOpenedAt   = 0;
static float g_menuMaxMove   = 0.0f;  // strongest movement input seen while the menu was open
static bool g_menuCloseAsked = false; // we asked the game to close it (bit 16)
static bool g_moveTipShown   = false;
static int  g_lastState      = -1;    // short_update's state, last logged
static bool g_weFaded        = false;
static bool g_musicAsked     = false; // we set bit 1 (the game starts the fast travel music)
static bool g_longTripLogged = false;

// While the screen is fading or the game is about to travel: no input, except
// pause (as the camp scripts do around their own fades).
static void HoldControls()
{
    N::DisableAllControlActions();
    N::EnableControlAction(H_FRONTEND_PAUSE);
    N::EnableControlAction(H_FRONTEND_PAUSE_ALT);
}

// The menu closed without a choice: log every condition short_update checks
// while it's open (func_80 state 1), so a log shows which one closed it.
static void LogMenuClosed(int now, int ped)
{
    bool kneeling = N::IsPedActiveInScenario(ped);
    Log("The fast travel menu closed without a choice after %.1f s. Kneeling %d (scenario task %d, exiting %d, "
        "in base %d), camp bit 23 %d, close asked %d, movement input seen %.2f, game flags 1357517=%d "
        "1935690=%d 1898068=%d.",
        (now - g_menuOpenedAt) / 1000.0, kneeling, N::PedHasUseScenarioTask(ped), N::IsPedExitingScenario(ped),
        N::PedIsInScenarioBase(ped), (G::Int(G::kCampFlags, 0) & G::CAMP_AT_FIRE) ? 1 : 0, g_menuCloseAsked,
        g_menuMaxMove, G::Int(G::kMenuStopA, -1), G::Int(G::kMenuStopB, -1), G::Int(G::kUiBusy, -1));
    if (!kneeling && !g_menuCloseAsked && g_menuMaxMove > 0.1f && !g_cfg.lockMovementInMenu)
    {
        Log("  Arthur got up from the kneel while the menu was open, after movement input. "
            "Use the arrow keys, mouse or D-pad in the menu, or try LockMovementInMenu=1.");
        if (!g_moveTipShown)
        {
            g_moveTipShown = true;
            HelpText(nullptr, "The fast travel menu closed because Arthur got up. In the menu, use the arrow keys, "
                              "the mouse or the D-pad: W/S and the left stick make him stand.");
        }
    }
}

static void SetPhase(int phase, int now)
{
    if (phase != g_phase)
        Log("Fast travel: %s -> %s (state %d, flags %d)", PhaseName(g_phase), PhaseName(phase),
            G::Int(G::kFtState, -1), G::Int(G::kFtFlags, -1));
    g_phase = phase;
    g_phaseStart = now;
}

static void RestoreCampBit()
{
    if (!g_weSetCampBit)
        return;
    g_weSetCampBit = false;
    int32_t camp;
    if (G::Get(G::kCampFlags, &camp) && (camp & G::CAMP_AT_FIRE))
        G::Set(G::kCampFlags, camp & ~G::CAMP_AT_FIRE);
}

static void SetFlag(int bit)
{
    int32_t fl;
    if (G::Get(G::kFtFlags, &fl))
        G::Set(G::kFtFlags, fl | bit);
}

static void ClearFlag(int bit)
{
    int32_t fl;
    if (G::Get(G::kFtFlags, &fl))
        G::Set(G::kFtFlags, fl & ~bit);
}

// Put the game's fast travel back to idle when it can't finish on its own, doing
// what short_update's state 6 and its func_81 would have done: the horses lose
// the "don't play dead" flag it gave them on bit 32 (PCF 388), the fast travel
// music stops, and the flags and state go back to 0.
static void ResetGameFastTravel()
{
    int slots[2] = { G::Int(G::kActiveHorse, -1), 1 };
    for (int i = 0; i < 2; i++)
    {
        if (slots[i] < 0 || slots[i] > 6)
            continue;
        int horse = G::Int(G::kHorsePeds + 1 + slots[i] * 45, 0);
        if (horse && N::DoesEntityExist(horse) && !N::IsEntityDead(horse))
            N::SetPedConfigFlag(horse, 388, 0);  // PCF_DisableFatallyWoundedBehaviour
    }
    if (g_musicAsked && !(G::Int(G::kFtFlags, 0) & G::FT_MUSIC))   // short_update started the music
        N::TriggerMusicEvent("OpenWorldMusic_FastTravel_StopEvent");
    g_musicAsked = false;
    G::Set(G::kFtFlags, 0);
    G::Set(G::kFtState, 0);
}

static void TurnOff(const char* fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    char why[200];
    vsnprintf(why, sizeof why, fmt, ap);
    va_end(ap);
    Log("ERROR: %s Fast Travel Anywhere is off until the game restarts.", why);
    snprintf(g_brokenWhy, sizeof g_brokenWhy,
             "Fast Travel Anywhere is off: the game's fast travel didn't respond. See FastTravelAnywhere.log.");
    Notify(9000, true, "%s: the game's fast travel didn't respond - turned off. See FastTravelAnywhere.log", FTA_NAME);
}

// Press: do what a campfire does (player_camp: SET bit 23 while at the fire,
// then bit 4 when Fast Travel is pressed).
static void StartRequest(int now)
{
    int32_t st, fl, camp;
    if (!G::Get(G::kFtState, &st) || !G::Get(G::kFtFlags, &fl) || !G::Get(G::kCampFlags, &camp) || st != 0)
        return;
    g_weSetCampBit = (camp & G::CAMP_AT_FIRE) == 0;
    if (g_weSetCampBit)
        G::Set(G::kCampFlags, camp | G::CAMP_AT_FIRE);
    G::Set(G::kFtFlags, (fl & ~G::FT_CLOSE) | G::FT_OPEN);   // a leftover close (16) would shut the new menu
    DeletePrompt();
    DeleteCampPrompt();
    Log("Fast Travel pressed: asking the game to open its fast travel menu "
        "(flags %d -> %d, camp bit 23 %s).", fl, (fl & ~G::FT_CLOSE) | G::FT_OPEN,
        g_weSetCampBit ? "set by us" : "already set by the game");
    g_lastState = 0;
    g_weFaded = false;
    g_musicAsked = false;
    g_longTripLogged = false;
    SetPhase(PH_REQUESTED, now);
}

static void Abort(int now, const char* why)
{
    Log("Fast travel: stopped (%s).", why);
    RestoreCampBit();
    if (g_weFaded && !N::IsFadedIn() && !N::IsFadingIn())
        N::FadeIn(800);
    g_weFaded = false;
    SetPhase(PH_IDLE, now);
}

static void FlowTick(int now, int ped)
{
    int st  = G::Int(G::kFtState, -1);
    int fl  = G::Int(G::kFtFlags, 0);
    int age = now - g_phaseStart;

    if (st != g_lastState)
    {
        if (g_cfg.debugLog || g_phase >= PH_FADING)
            Log("Game fast travel state %d -> %d (flags %d)", g_lastState, st, fl);
        g_lastState = st;
    }

    switch (g_phase)
    {
    case PH_REQUESTED:
        if (N::IsEntityDead(ped))
        {
            ClearFlag(G::FT_OPEN);
            Abort(now, "the player died");
            break;
        }
        if (st == 1 || st >= 2)
        {
            g_menuSeenAt = now;
            g_menuOpenedAt = now;
            g_menuMaxMove = 0.0f;
            g_menuCloseAsked = false;
            Log("The game opened its fast travel menu.");
            SetPhase(PH_MENU, now);
            break;
        }
        if (!(fl & G::FT_OPEN))
        {
            // short_update took the request but found no place to go
            // (short_update func_495 found nothing): the game's own message.
            RestoreCampBit();
            Log("The game found no place to fast travel to.");
            HelpText("NO_REGION_FT", "Discover more regions to use fast travel. Regions in lockdown are unavailable.");
            SetPhase(PH_IDLE, now);
            break;
        }
        if (age > 3000)
        {
            ClearFlag(G::FT_OPEN);
            RestoreCampBit();
            TurnOff("The game didn't pick up the fast travel request within 3 s (short_update threads %d, "
                    "state %d, flags %d).", N::ScriptThreads(H_SHORT_UPDATE), st, fl);
            SetPhase(PH_IDLE, now);
        }
        break;

    case PH_MENU:
        if (st == 1)
        {
            // Under the menu, the kneel menu's own Craft (R) and Set Up Camp (E)
            // must not fire (a campfire disables its prompts while the menu is up).
            N::DisableControlAction(H_INPUT_CONTEXT_X);
            N::DisableControlAction(H_INPUT_CONTEXT_Y);
            if (g_cfg.lockMovementInMenu)
            {
                // Menu-only controls: the kneel script reads movement even when
                // it's disabled, but not outside the active control context.
                N::SetControlContext(4, H_CTX_FRONTEND_MENU);
            }
            {
                float lr = N::DisabledControlNormal(H_INPUT_MOVE_LR);
                float ud = N::DisabledControlNormal(H_INPUT_MOVE_UD);
                float m = lr * lr + ud * ud;
                if (m > g_menuMaxMove)
                    g_menuMaxMove = m;
            }
            if (N::IsUiAppActive(H_FAST_TRAVEL_MENU))
                g_menuSeenAt = now;
            else if (now - g_menuSeenAt > 2500)
            {
                // Open on paper, but the app isn't showing: let the game close it
                // the way a campfire does when it shuts down (bit 16).
                Log("The fast travel menu isn't showing; asking the game to close it.");
                SetFlag(G::FT_CLOSE);
                g_menuCloseAsked = true;
                g_menuSeenAt = now;
            }
            break;
        }
        if (st == 0 || st < 0)
        {
            LogMenuClosed(now, ped);   // before the camp bit goes back: the log shows it as the game saw it
            RestoreCampBit();
            SetPhase(PH_IDLE, now);
            break;
        }
        RestoreCampBit();
        // st 2: a place was chosen. Now the camp's part (player_camp state 13):
        // the camp starts the fast travel music (bit 1) with its animation,
        // and the screen fades out.
        Log("A place was chosen. Fading out.");
        SetFlag(G::FT_MUSIC);
        g_musicAsked = true;
        if (g_cfg.standUp)
            N::GivePedHashCommand(ped, H_KNEEL_EXIT, 2.0f);  // the kneel menu's own Leave
        if (!N::IsFadedOut() && !N::IsFadingOut())
        {
            N::FadeOut(1000);
            g_weFaded = true;
        }
        SetPhase(PH_FADING, now);
        break;

    case PH_FADING:
        HoldControls();
        if (st == 0)
        {
            Abort(now, "the game reset its fast travel");
            break;
        }
        if (N::IsEntityDead(ped))
        {
            // short_update would wait for the camp forever: reset it as its own
            // cleanup does (func_81). The death screen takes over the fade.
            ResetGameFastTravel();
            g_weFaded = false;
            Abort(now, "the player died before leaving");
            break;
        }
        if (st >= 4)
        {
            // Something else set bit 32 already (player_camp's cleanup sets it
            // whenever the state is 2, e.g. a camp set up elsewhere being packed
            // away): the game is on its way. Leave the player and the bit alone.
            Log("The game started the trip by itself before the fade ended.");
            SetPhase(PH_TRAVEL, now);
            break;
        }
        if (N::IsFadedOut() || age > 4000)
        {
            // The camp clears the player's tasks before its exit scene, then
            // sets bit 32 once it has packed up.
            N::ClearPedTasksImmediately(ped);
            SetFlag(G::FT_READY);
            Log("Screen faded out: told the game to travel (bit 32).");
            SetPhase(PH_TRAVEL, now);
        }
        break;

    case PH_TRAVEL:
        if (st == 2)
        {
            HoldControls();
            if (age > 12000)
            {
                // The game never started the trip (short_update func_512 refused,
                // e.g. a horse that can't be mounted).
                Log("ERROR: the game didn't start the trip within 12 s (flags %d). Resetting it.", fl);
                ResetGameFastTravel();
                if (N::IsFadedOut() || N::IsFadingOut())
                    N::FadeIn(800);
                g_weFaded = false;
                HelpText(nullptr, "Fast travel didn't start. Try again.");
                SetPhase(PH_IDLE, now);
            }
            break;
        }
        if (st == 0)
        {
            Log("The game finished the trip.");
            g_musicAsked = false;
            SetPhase(PH_ARRIVED, now);
            break;
        }
        if (age > 120000 && !g_longTripLogged)
        {
            // Still loading the place after 2 minutes: give the player the
            // screen back, but leave the game's trip alone.
            g_longTripLogged = true;
            Log("The trip is still going after 2 minutes (state %d).%s", st,
                N::IsFadedOut() ? " Fading the screen back in." : "");
            if (N::IsFadedOut())
                N::FadeIn(1000);
        }
        break;

    case PH_ARRIVED:
        if (N::IsFadedIn() || N::IsFadingIn())
        {
            g_weFaded = false;
            SetPhase(PH_IDLE, now);
            break;
        }
        if (age > 3000)
        {
            if (N::IsFadedOut())
            {
                N::FadeIn(1000);
                Log("The screen was still black after the trip: faded it back in.");
            }
            g_weFaded = false;
            SetPhase(PH_IDLE, now);
        }
        break;
    }
}

// ===========================================================================
// Waypoint travel
// ===========================================================================
//
// With a waypoint on the map (WaypointTravel=1), Fast Travel takes you straight
// there instead of opening the game's fast travel menu. The game has no trip of
// its own to a waypoint (none of its scripts even reads the waypoint's
// position), so the plugin makes it the way the game's own trips make theirs
// (train_fast_travel_core, and short_update's trip to a spot, its func_1610):
// the screen fades out, the player and the horses are held at the place while
// it streams in (LOAD_SCENE_START_SPHERE, REQUEST_COLLISION_AT_COORD), the
// horse is put down there and the player in its saddle, and the screen fades
// back in.
//
// The place: the point of the GPS route (the line to the waypoint) closest to
// the waypoint, when the route runs on roads (short_update asks
// _IS_PATH_FOR_GPS_ON_ROAD before it trusts one): the road nearest it, whose
// height is known. Otherwise the waypoint itself, whose ground is found as the
// area loads, trying heights (as trainers' "teleport to waypoint" do). Either
// way the ground is checked once the place is in, and looked for the same way
// if it isn't where the route said. In deep water, the nearest shore (a safe
// spot for a ped, not in water), else the road nearest the waypoint. With no
// ground found, back to where the trip began.
//
// Not where the game keeps Arthur out: New Austin, where its sniper shoots him
// (medium_update func_97), and Blackwater, which its fast travel menu leaves
// out for him (short_update func_1576). The menu opens instead.
//
// The clock moves on by the ride's length (AdvanceClock=1): the GPS route's
// length (else the straight line * 1.3) at a steady gallop, or on foot when no
// horse comes along. A game minute is 2 seconds.

static const float kWaypointNear     = 60.0f;   // a waypoint this close counts as reached: the menu instead
static const float kRoadMaxOff       = 300.0f;  // the GPS route's closest point, if it's this close to the waypoint
static const float kShoreMax         = 150.0f;  // out of deep water: a dry spot this close
static const float kRideMetresPerMin = 18.0f;   // a steady gallop, about 9 m/s
static const float kWalkMetresPerMin = 8.0f;    // on foot
static const int   kProbeMaxMs       = 20000;   // how long to look for the ground at the waypoint
static const float kProbeHeights[]   = { 100.0f, 150.0f, 50.0f, 0.0f, 200.0f, 250.0f, 300.0f, 350.0f, 400.0f,
                                         450.0f, 500.0f, 550.0f, 600.0f, 650.0f, 700.0f, 800.0f, 900.0f, 1000.0f };
static const int   kProbeCount       = (int)(sizeof kProbeHeights / sizeof kProbeHeights[0]);

struct WaypointTarget
{
    N::Vec3 wp;          // the waypoint (its z is always 0)
    N::Vec3 dest;        // where to arrive
    bool    knownZ;      // dest.z is real (the road nearest the waypoint)
    float   roadOff;     // how far the road nearest the waypoint is from it
    N::Vec3 road;        // that road point, however far (somewhere to go from a waypoint in water)
    bool    hasRoad;
    float   straight;    // metres from the player to the waypoint, as the crow flies
    float   ride;        // metres to ride: the GPS route's length, else the straight line * 1.3
    bool    route;       // the GPS route's length was used
};

// What Fast Travel does with the waypoint.
enum WaypointUse
{
    WU_NONE,         // none on the map (or WaypointTravel=0): the menu
    WU_GO,           // off to it
    WU_HERE,         // it's right here: the menu
    WU_ARRIVED,      // the last trip to it ended right here (at the road nearest it): the menu
    WU_NEW_AUSTIN,   // Arthur, and it's in New Austin: the menu
    WU_BLACKWATER,   // Arthur, and it's in Blackwater: the menu
};

// Where the game keeps Arthur out (WU_NEW_AUSTIN, WU_BLACKWATER), else 0: New
// Austin's districts, where medium_update's sniper shoots him (func_97:
// districts 13 to 16 of its func_866, unless Global_1934266.f_56 turns it
// off), and the town of Blackwater, which short_update's fast travel menu
// leaves out for him (func_1576). The zones are looked up at a few heights as
// well, a waypoint having none.
static int PlaceRestricted(int ped, float x, float y, float z)
{
    if (N::EntityModel(ped) != H_PLAYER_ZERO)
        return 0;
    bool sniper = G::Int(G::kSniperOff, 0) == 0;
    static const float kZs[] = { 0.0f, 50.0f, 100.0f, 200.0f, 300.0f, 500.0f, 800.0f };
    for (int i = -1; i < (int)(sizeof kZs / sizeof kZs[0]); i++)
    {
        float zz = i < 0 ? z : kZs[i];
        uint32_t district = N::MapZoneAt(x, y, zz, 10);
        if (sniper && (district == H_GAPTOOTH_RIDGE || district == H_RIO_BRAVO || district == H_CHOLLA_SPRINGS ||
                       district == H_HENNIGANS_STEAD))
            return WU_NEW_AUSTIN;
        if (N::MapZoneAt(x, y, zz, 1) == H_BLACKWATER)
            return WU_BLACKWATER;
    }
    return 0;
}

// Where the last trip to a waypoint ended: being there with the same waypoint
// counts as having reached it (the road nearest it may be some way from it).
static bool  g_wtLastValid = false;
static float g_wtLastWpX = 0.0f, g_wtLastWpY = 0.0f, g_wtLastAtX = 0.0f, g_wtLastAtY = 0.0f;

// The waypoint's zones, worked out again when it moves, every 2 s, and with each kneel.
static float g_wuZoneX = 1e9f, g_wuZoneY = 1e9f;
static int   g_wuZonePed = 0, g_wuZoneAt = 0, g_wuZone = 0;
static void  WaypointZonesStale() { g_wuZonePed = 0; }

static int WaypointUseFor(int ped, float* distOut)
{
    if (distOut)
        *distOut = 0.0f;
    if (!g_cfg.waypointTravel || !N::IsWaypointActive())
        return WU_NONE;
    N::Vec3 me = N::EntityCoords(ped);
    N::Vec3 wp = N::WaypointCoords();
    float dx = wp.x - me.x, dy = wp.y - me.y;
    float d = sqrtf(dx * dx + dy * dy);
    if (distOut)
        *distOut = d;
    if (d < kWaypointNear)
        return WU_HERE;
    if (g_wtLastValid && fabsf(wp.x - g_wtLastWpX) < 1.0f && fabsf(wp.y - g_wtLastWpY) < 1.0f)
    {
        float ax = me.x - g_wtLastAtX, ay = me.y - g_wtLastAtY;
        if (ax * ax + ay * ay < kWaypointNear * kWaypointNear)
            return WU_ARRIVED;
    }
    int now = N::GameTimer();
    if (wp.x != g_wuZoneX || wp.y != g_wuZoneY || ped != g_wuZonePed || now - g_wuZoneAt > 2000 || now < g_wuZoneAt)
    {
        g_wuZoneX = wp.x;
        g_wuZoneY = wp.y;
        g_wuZonePed = ped;
        g_wuZoneAt = now;
        g_wuZone = PlaceRestricted(ped, wp.x, wp.y, me.z);
    }
    return g_wuZone ? g_wuZone : WU_GO;
}

static const char* WaypointUseText(int wu, float dist)
{
    static char buf[64];
    switch (wu)
    {
    case WU_GO:
        snprintf(buf, sizeof buf, "to your waypoint, %.0f m away", dist);
        return buf;
    case WU_HERE:       return "the game's fast travel menu; your waypoint is right here";
    case WU_ARRIVED:    return "the game's fast travel menu; you're at the road nearest your waypoint";
    case WU_NEW_AUSTIN: return "the game's fast travel menu: your waypoint is in New Austin, where the game doesn't let Arthur go";
    case WU_BLACKWATER: return "the game's fast travel menu: your waypoint is in Blackwater, which the game's fast travel "
                               "leaves out for Arthur";
    }
    return !g_cfg.waypointTravel && N::IsWaypointActive() ? "the game's fast travel menu: WaypointTravel=0"
                                                          : "the game's fast travel menu: no waypoint set";
}

static void FindWaypointTarget(int ped, WaypointTarget* t)
{
    memset(t, 0, sizeof *t);
    N::Vec3 me = N::EntityCoords(ped);
    t->wp = N::WaypointCoords();
    t->wp.z = 0.0f;
    float dx = t->wp.x - me.x, dy = t->wp.y - me.y;
    t->straight = sqrtf(dx * dx + dy * dy);
    t->dest = t->wp;
    t->dest.z = me.z;
    // The GPS route's point closest to the waypoint, when the route runs on
    // roads. Asked at the player's height, then again at that point's own, so
    // that a lower road elsewhere on the route doesn't come out closer.
    N::Vec3 r = {};
    if (N::GpsPathOnRoad() && N::ClosestGpsPosition(t->wp.x, t->wp.y, me.z, &r))
    {
        N::Vec3 r2 = {};
        if (N::ClosestGpsPosition(t->wp.x, t->wp.y, r.z, &r2))
            r = r2;
        float rx = r.x - t->wp.x, ry = r.y - t->wp.y;
        float off = sqrtf(rx * rx + ry * ry);
        if (r.z > -100.0f && r.z < 2000.0f && !PlaceRestricted(ped, r.x, r.y, r.z))
        {
            t->road = r;
            t->hasRoad = true;
            t->roadOff = off;
            if (off <= kRoadMaxOff)
            {
                t->dest = r;
                t->knownZ = true;
            }
        }
    }
    // The ride: the GPS route's length if it fits a ride to the waypoint (a
    // route to somewhere else, a mission's, wouldn't), else the straight line
    // * 1.3.
    int len = N::GpsRouteFound() ? N::GpsRouteLength() : 0;
    t->route = len > 0 && (float)len >= t->straight * 0.8f - 400.0f && (float)len <= t->straight * 4.0f + 1000.0f;
    t->ride = t->route ? (float)len : t->straight * 1.3f;
}

// Heading (degrees, the game's way: 0 = north, counterclockwise) from (x1, y1) toward (x2, y2).
static float HeadingTo(float x1, float y1, float x2, float y2)
{
    float h = atan2f(-(x2 - x1), y2 - y1) * 57.2957795f;
    return h < 0.0f ? h + 360.0f : h;
}

enum WtPhase
{
    WT_IDLE,
    WT_FADING,    // Arthur stands up, the screen fades out
    WT_PROBING,   // finding the ground: trying heights while the area loads
    WT_LOADING,   // the place (its height known) streaming in, the player held there
    WT_FADEIN,    // arrived: the screen comes back, the player unhurtable until he's down
};

static int            g_wtPhase   = WT_IDLE;
static int            g_wtPhaseAt = 0;
static int            g_wtTickAt  = 0;          // the last tick (the clocks stop while the game is paused)
static WaypointTarget g_wt;
static int            g_wtPed = 0, g_wtHorse = 0, g_wtHorse2 = 0;
static N::Vec3        g_wtOrigin;               // where the trip began (to go back to if the place won't do)
static N::Vec3        g_wtGoal;                 // where the player is held while it loads
static bool           g_wtReturning  = false;
static bool           g_wtProbed     = false;   // the ground has been looked for (once)
static bool           g_wtShore      = false;   // gone from deep water to dry land (once)
static const char*    g_wtFailMsg    = nullptr; // the message when it went back
static int            g_wtProbe      = 0;       // the height being tried (kProbeHeights)
static int            g_wtProbeAt    = 0;
static int            g_wtProbeStart = 0;
static int            g_wtGuarded    = 0;       // bits: the plugin made the player (1), the horse (2), the second horse (4) unhurtable
static bool           g_wtScene      = false;   // the plugin's load scene is running
static bool           g_wtWeFaded    = false;
static int            g_wtMinutes    = 0;

static void WtSetPhase(int phase, int now)
{
    g_wtPhase   = phase;
    g_wtPhaseAt = now;
}

// Deep water at (x, y), over the ground at z (deeper than a metre): its surface.
static bool DeepWater(float x, float y, float z, float* surface)
{
    float s = 0.0f;
    if (N::WaterProbe(x, y, z + 100.0f, &s) == 1 && s > z + 1.0f)
    {
        *surface = s;
        return true;
    }
    return false;
}

// The player and the horses held, frozen, at the spot (a metre up, above any
// water there) while it loads.
static void WtHold(float x, float y, float z)
{
    float s;
    if (DeepWater(x, y, z, &s))
        z = s;
    N::SetEntityCoords(g_wtPed, x, y, z + 1.0f);
    N::FreezePosition(g_wtPed, 1);
    if (g_wtHorse)
    {
        N::SetEntityCoords(g_wtHorse, x + 2.0f, y, z + 1.0f);
        N::FreezePosition(g_wtHorse, 1);
    }
    if (g_wtHorse2)
    {
        N::SetEntityCoords(g_wtHorse2, x - 2.0f, y, z + 1.0f);
        N::FreezePosition(g_wtHorse2, 1);
    }
}

// Only the plugin's own load scene is ever stopped.
static void WtStopScene()
{
    if (g_wtScene && N::IsLoadSceneActive())
        N::LoadSceneStop();
    g_wtScene = false;
}

static void WtStartScene(float x, float y, float z, float radius)
{
    WtStopScene();
    g_wtScene = N::LoadSceneStartSphere(x, y, z, radius);
}

// Unhurtable on the way: each of them only if it could be hurt, and put back as it was.
static void WtGuard(int bit, int e)
{
    if (e && N::DoesEntityExist(e) && N::CanBeDamaged(e))
    {
        N::SetCanBeDamaged(e, 0);
        g_wtGuarded |= bit;
    }
}

static void WtUnguard()
{
    const int ents[3] = { g_wtPed, g_wtHorse, g_wtHorse2 };
    for (int i = 0; i < 3; i++)
        if ((g_wtGuarded & (1 << i)) && ents[i] && N::DoesEntityExist(ents[i]))
            N::SetCanBeDamaged(ents[i], 1);
    g_wtGuarded = 0;
}

static void WtUnfreeze()
{
    const int ents[3] = { g_wtPed, g_wtHorse, g_wtHorse2 };
    for (int i = 0; i < 3; i++)
        if (ents[i] && N::DoesEntityExist(ents[i]))
            N::FreezePosition(ents[i], 0);
    WtStopScene();
}

// Stop where things are: let go of the player and the horses, and give the
// screen back, unless the game's death screen takes it over.
static void WtAbort(int now, const char* why, bool fadeIn)
{
    Log("Waypoint travel: stopped (%s).", why);
    WtUnfreeze();
    WtUnguard();
    if (fadeIn && g_wtWeFaded && (N::IsFadedOut() || N::IsFadingOut()))
        N::FadeIn(800);
    g_wtWeFaded = false;
    WtSetPhase(WT_IDLE, now);
}

// A save loading, or an online session: what the trip held went with the old
// world. Forget the trip without touching anything.
static void WtDrop(const char* why)
{
    Log("Waypoint travel: dropped (%s).", why);
    g_wtGuarded = 0;
    g_wtScene = false;
    g_wtWeFaded = false;
    g_wtPhase = WT_IDLE;
}

// Off to a spot whose height is known: held there while it loads.
static void WtGoTo(int now, N::Vec3 goal)
{
    g_wtGoal = goal;
    WtHold(goal.x, goal.y, goal.z);
    WtStartScene(goal.x, goal.y, goal.z, 60.0f);
    WtSetPhase(WT_LOADING, now);
}

// Off to a spot whose height isn't known: heights are tried until the ground shows.
static void WtProbe(int now, float x, float y)
{
    g_wtProbed = true;
    g_wtGoal.x = x;
    g_wtGoal.y = y;
    g_wtGoal.z = kProbeHeights[0];
    g_wtProbe = 0;
    g_wtProbeAt = g_wtProbeStart = now;
    WtHold(x, y, kProbeHeights[0]);
    WtStartScene(x, y, kProbeHeights[0], 100.0f);
    WtSetPhase(WT_PROBING, now);
}

static void StartWaypointTravel(int now, int ped)
{
    FindWaypointTarget(ped, &g_wt);
    DeletePrompt();
    DeleteCampPrompt();
    g_wtPed = ped;
    g_wtHorse = g_wtHorse2 = 0;
    g_wtOrigin = N::EntityCoords(ped);
    g_wtReturning = g_wtProbed = g_wtShore = false;
    g_wtFailMsg = nullptr;
    g_wtGuarded = 0;
    g_wtScene = false;
    g_wtWeFaded = false;
    g_wtTickAt = now;
    const char* how = g_wt.route ? " by the GPS route" : ", the straight line x 1.3";
    if (g_wt.knownZ)
        Log("Fast Travel pressed: travelling to your waypoint, %.0f m away (to the road %.0f m from it; ride %.0f m%s).",
            g_wt.straight, g_wt.roadOff, g_wt.ride, how);
    else
        Log("Fast Travel pressed: travelling to your waypoint, %.0f m away (no road near it: to the waypoint itself, "
            "its ground found on arrival; ride %.0f m%s).", g_wt.straight, g_wt.ride, how);
    if (g_cfg.standUp)
        N::GivePedHashCommand(ped, H_KNEEL_EXIT, 2.0f);   // the kneel menu's own Leave
    if (!N::IsFadedOut() && !N::IsFadingOut())
    {
        N::FadeOut(1000);
        g_wtWeFaded = true;
    }
    WtSetPhase(WT_FADING, now);
}

// The screen is black: who comes along, then off.
static void WtDepart(int now, int ped)
{
    // The horses, as short_update picks them (func_80 state 2): the active
    // horse if it's within whistling range, else the slot-1 horse if that one
    // is; and the slot-1 horse as well, if it's in range too.
    HorseInfo a, b;
    HorseCheck(ped, &a, &b);
    bool nearA = a.exists && !a.dead && a.range >= 0.0f && a.dist <= a.range;
    bool nearB = b.exists && !b.dead && b.range >= 0.0f && b.dist <= b.range;
    if (nearA)
    {
        g_wtHorse = a.ped;
        g_wtHorse2 = (nearB && b.ped != a.ped) ? b.ped : 0;
    }
    else if (nearB)
        g_wtHorse = b.ped;

    // A horse at a hitching post comes off it first, as the game's own trips do (func_1618).
    const uint32_t hitchingPost = Joaat("PROP_HITCHINGPOST");
    if (g_wtHorse && N::IsPedUsingScenarioHash(g_wtHorse, hitchingPost))
        N::UnhitchHorse(g_wtHorse);
    if (g_wtHorse2 && N::IsPedUsingScenarioHash(g_wtHorse2, hitchingPost))
        N::UnhitchHorse(g_wtHorse2);

    N::ClearPedTasksImmediately(ped);
    WtGuard(1, ped);
    WtGuard(2, g_wtHorse);
    WtGuard(4, g_wtHorse2);

    g_wtMinutes = 0;
    if (g_cfg.advanceClock)
    {
        float perMin = g_wtHorse ? kRideMetresPerMin : kWalkMetresPerMin;
        int m = (int)(g_wt.ride / perMin + 0.5f);
        g_wtMinutes = m < 1 ? 1 : m > 24 * 60 ? 24 * 60 : m;
    }
    Log("Waypoint travel: screen black; %s%s.", g_wtHorse ? "the horse comes along" : "on foot (no horse in whistling range)",
        g_wtHorse2 ? ", and the second horse" : "");
    if (g_wt.knownZ)
        WtGoTo(now, g_wt.dest);
    else
        WtProbe(now, g_wt.dest.x, g_wt.dest.y);
}

// On the ground there, on the horse, the clock moved on, the screen back.
static void WtArrive(int now, float x, float y, float z)
{
    int ped = g_wtPed;
    // A spot a ped can stand on, not indoors and not in water (12, as the
    // game's scripts ask for it).
    N::Vec3 safe = {};
    bool safeOk = false;
    if (N::SafeCoordForPed(x, y, z + 1.0f, &safe, 12))
    {
        float sx = safe.x - x, sy = safe.y - y;
        if (sx * sx + sy * sy <= 40.0f * 40.0f && fabsf(safe.z - z) < 20.0f)
        {
            x = safe.x; y = safe.y; z = safe.z;
            safeOk = true;
        }
    }
    // Facing the waypoint when it's off the road, else on along the way.
    float hx = g_wt.wp.x - x, hy = g_wt.wp.y - y;
    float heading = (hx * hx + hy * hy > 25.0f) ? HeadingTo(x, y, g_wt.wp.x, g_wt.wp.y)
                                                : HeadingTo(g_wtOrigin.x, g_wtOrigin.y, x, y);
    if (g_wtReturning)
        heading = HeadingTo(x, y, g_wt.wp.x, g_wt.wp.y);

    WtUnfreeze();   // still unhurtable until he's down (WT_FADEIN)
    bool mounted = false;
    bool horseThere = g_wtHorse && N::DoesEntityExist(g_wtHorse) && !N::IsEntityDead(g_wtHorse);
    if (horseThere)
    {
        // As short_update's func_1610: the horse on the ground there, then the player in its saddle.
        N::SetEntityCoordsAndHeading(g_wtHorse, x, y, z, heading);
        if (!N::PlaceOnGround(g_wtHorse))
            Log("Waypoint travel: the game couldn't put the horse on the ground there.");
        N::SetPedConfigFlag(g_wtHorse, 136, 0);   // PCF_CannotBeMounted off
        if (N::CanPedBeMounted(g_wtHorse))
        {
            if (N::GetMount(ped) != g_wtHorse)
            {
                N::SetPedOntoMount(ped, g_wtHorse);
                N::SetPedCanBeTargetted(g_wtHorse, 0);   // as the game's func_2856
            }
            mounted = true;
        }
    }
    if (!mounted)
    {
        float px = x, py = y;
        if (horseThere)
        {
            N::Vec3 side = N::OffsetInWorld(g_wtHorse, 1.5f, 0.0f, 0.0f);   // beside it
            px = side.x;
            py = side.y;
            Log("Waypoint travel: the horse can't be mounted right now; it stays next to you.");
        }
        N::SetEntityCoordsAndHeading(ped, px, py, z, heading);
        if (!N::PlaceOnGround(ped))
            Log("Waypoint travel: the game couldn't put you on the ground there.");
    }
    if (g_wtHorse2 && N::DoesEntityExist(g_wtHorse2) && !N::IsEntityDead(g_wtHorse2))
    {
        // Behind on the right, as short_update's func_518 (2, -2), worked out from
        // the spot and the heading: the player may not be in the saddle's place yet.
        float hr = heading * 0.0174532925f;
        float fx = -sinf(hr), fy = cosf(hr);   // ahead
        float rx = cosf(hr), ry = sinf(hr);    // to the right
        N::SetEntityCoordsAndHeading(g_wtHorse2, x + rx * 2.0f - fx * 2.0f, y + ry * 2.0f - fy * 2.0f, z, heading);
        N::PlaceOnGround(g_wtHorse2);
    }
    N::SetGameplayCamRelativeHeading(0.0f);

    if (!g_wtReturning && g_wtMinutes > 0)
    {
        int h0 = N::ClockHours(), m0 = N::ClockMinutes();
        N::AddToClockTime(g_wtMinutes / 60, g_wtMinutes % 60, 0);
        Log("Waypoint travel: the clock moved on %d:%02d (%02d:%02d -> %02d:%02d).", g_wtMinutes / 60, g_wtMinutes % 60,
            h0, m0, N::ClockHours(), N::ClockMinutes());
    }
    float wx = g_wt.wp.x - x, wy = g_wt.wp.y - y;
    Log("Waypoint travel: %s at %.1f, %.1f, %.1f, %.0f m from the waypoint%s; %s.",
        g_wtReturning ? "back" : "arrived", x, y, z, sqrtf(wx * wx + wy * wy), safeOk ? " (a safe spot nearby)" : "",
        mounted ? "on the horse" : "on foot");
    if (g_wtReturning)
        HelpText(nullptr, g_wtFailMsg ? g_wtFailMsg : "Couldn't find solid ground at your waypoint. Try a waypoint on or near a road.");
    else
    {
        g_wtLastValid = true;
        g_wtLastWpX = g_wt.wp.x;
        g_wtLastWpY = g_wt.wp.y;
        g_wtLastAtX = x;
        g_wtLastAtY = y;
    }
    N::FadeIn(1500);
    g_wtWeFaded = false;
    WtSetPhase(WT_FADEIN, now);
}

// Somewhere the place won't do: go back to where the trip began, once.
static void WtGiveUp(int now, const char* why)
{
    if (g_wtReturning)
    {
        Log("Waypoint travel: %s on the way back too; putting you down where the trip began.", why);
        WtArrive(now, g_wtOrigin.x, g_wtOrigin.y, g_wtOrigin.z);
        return;
    }
    Log("Waypoint travel: %s; going back to where the trip began.", why);
    g_wtReturning = true;
    WtGoTo(now, g_wtOrigin);
}

// Loaded: the ground checked, out of deep water, then down there.
static void WtSettle(int now)
{
    float x = g_wtGoal.x, y = g_wtGoal.y, z = g_wtGoal.z;
    // The ground right there: from just above where it should be, else from higher up.
    float gz;
    bool ground = (N::GroundZ(x, y, z + 3.0f, &gz) && fabsf(gz - z) < 20.0f) ||
                  (N::GroundZ(x, y, z + 50.0f, &gz) && gz > z - 20.0f);
    if (ground)
        z = gz;
    else if (!g_wtReturning && !g_wtProbed)
    {
        Log("Waypoint travel: no ground at %.0f, %.0f, %.1f, where the route said; looking for it.", x, y, z);
        WtProbe(now, x, y);
        return;
    }

    // Deep water (a waypoint in a lake, say): to the nearest shore, else to the road nearest the waypoint.
    float surface;
    if (!g_wtReturning && !g_wtShore && DeepWater(x, y, z, &surface))
    {
        g_wtShore = true;
        N::Vec3 s = {};
        if (N::SafeCoordForPed(x, y, surface, &s, 12))
        {
            float sx = s.x - x, sy = s.y - y;
            float d = sqrtf(sx * sx + sy * sy);
            if (d <= kShoreMax && !PlaceRestricted(g_wtPed, s.x, s.y, s.z))
            {
                Log("Waypoint travel: the waypoint is in deep water (%.1f m); going to the shore, %.0f m away.",
                    surface - z, d);
                WtGoTo(now, s);
                return;
            }
        }
        if (g_wt.hasRoad)
        {
            Log("Waypoint travel: the waypoint is in deep water (%.1f m), no shore near it; going to the road "
                "nearest it, %.0f m from it.", surface - z, g_wt.roadOff);
            WtGoTo(now, g_wt.road);
            return;
        }
        g_wtFailMsg = "Your waypoint is in deep water. Try a waypoint on land.";
        WtGiveUp(now, "the waypoint is in deep water, with no shore or road near it");
        return;
    }
    WtArrive(now, x, y, z);
}

static void WaypointTick(int now, int ped)
{
    // The pause menu stops the trip's clocks.
    int dt = now - g_wtTickAt;
    g_wtTickAt = now;
    if (N::IsPauseMenuActive())
    {
        g_wtPhaseAt += dt;
        g_wtProbeAt += dt;
        g_wtProbeStart += dt;
        return;
    }
    int age = now - g_wtPhaseAt;

    if (g_wtPhase != WT_FADEIN)
    {
        HoldControls();
        if (ped != g_wtPed)
        {
            WtAbort(now, "the player changed", true);
            return;
        }
        if (N::IsEntityDead(ped))
        {
            WtAbort(now, "the player died", false);   // the death screen takes over the fade
            return;
        }
    }

    switch (g_wtPhase)
    {
    case WT_FADING:
        if (N::IsFadedOut() || age > 4000)
            WtDepart(now, ped);
        break;

    case WT_PROBING:
    {
        float h = kProbeHeights[g_wtProbe];
        N::RequestCollisionAt(g_wtGoal.x, g_wtGoal.y, h);
        bool coll = N::CollisionLoadedAround(ped);
        float gz;
        if (coll && N::GroundZ(g_wtGoal.x, g_wtGoal.y, h + 1.0f, &gz))
        {
            Log("Waypoint travel: the ground at the waypoint is at %.1f (found from %.0f, %.1f s in).", gz, h,
                (now - g_wtProbeStart) / 1000.0);
            N::Vec3 goal = g_wtGoal;
            goal.z = gz;
            WtGoTo(now, goal);
            break;
        }
        // Loaded here and nothing below: the ground is higher, or not in yet.
        // Not loaded yet: a moment for it. Round the heights again until 20 s.
        if ((coll && now - g_wtProbeAt > 500) || now - g_wtProbeAt > 1500)
        {
            if (now - g_wtProbeStart > kProbeMaxMs)
            {
                WtGiveUp(now, "no ground found at the waypoint");
                break;
            }
            g_wtProbe = (g_wtProbe + 1) % kProbeCount;
            g_wtProbeAt = now;
            WtHold(g_wtGoal.x, g_wtGoal.y, kProbeHeights[g_wtProbe]);
        }
        break;
    }

    case WT_LOADING:
    {
        N::RequestCollisionAt(g_wtGoal.x, g_wtGoal.y, g_wtGoal.z);
        bool coll  = N::CollisionLoadedAround(ped);
        bool scene = !g_wtScene || !N::IsLoadSceneActive() || N::IsLoadSceneLoaded();
        // The navmesh, for a safe spot (the game's scripts check a few metres around a spot)
        bool nav   = N::NavmeshLoadedIn(g_wtGoal.x - 2.0f, g_wtGoal.y - 2.0f, g_wtGoal.z - 2.0f,
                                        g_wtGoal.x + 2.0f, g_wtGoal.y + 2.0f, g_wtGoal.z + 2.0f);
        if (coll && (scene || age > 8000) && (nav || age > 10000) && age > 500)
        {
            if (!scene)
                Log("Waypoint travel: the area is still loading after 8 s; its ground is in, going ahead.");
            if (!nav)
                Log("Waypoint travel: the area's navmesh isn't in after 10 s; going ahead.");
            WtSettle(now);
        }
        else if (age > 15000)
            WtGiveUp(now, "the place didn't load within 15 s");
        break;
    }

    case WT_FADEIN:
        // The screen back; unhurtable until he's down (not falling), 6 s at most.
        if (N::IsFadedIn() || age > 4000)
        {
            if (!N::IsFadedIn() && !N::IsFadingIn())
                N::FadeIn(800);
            if (age < 6000 && N::IsPedFalling(ped))
                break;
            WtUnguard();
            Log("Waypoint travel: done.");
            WtSetPhase(WT_IDLE, now);
        }
        break;
    }
}

// ===========================================================================
// Set Up Camp anywhere
// ===========================================================================
//
// The kneel menu has Set Up Camp (E) only where the game lets you make camp:
// dynamic_craft_scenario adds it (state 1 -> 2) if its func_21 says yes, and
// that says no in a town or an interior, near train tracks, next to someone
// with a mission for you, and so on. Where it's left out, the plugin adds the
// same button, and a press starts the game's camp the way that button does
// (func_27 for KIT_CAMP): player_camp, with the same arguments. player_camp
// does the rest as always: Arthur gets up and pitches camp, the screen fades,
// and the camp goes up at the nearest of the game's campsites (its list of
// camping locations per district, func_72), which from a town is outside it.
//
// The button is added only once the kneel menu's own prompts have been found
// in the game's shared prompt list (Global_1945188) without a Set Up Camp
// among them, so there are never two. The game's camping rules that aren't
// about the place still apply, as func_21 has them.

enum CampReason
{
    C_OK = 0,
    C_OFF,          // SetUpCampAnywhere=0
    C_UNSUPPORTED,  // the script globals don't look like build 1491.50
    C_GAME_HAS_IT,  // the kneel menu has its own Set Up Camp here
    C_NO_LIST,      // the kneel menu's own prompts weren't found: no second button risked
    C_NO_KIT,
    C_CAMP_UP,      // a camp is already up, or you're at a campsite
    C_BLOCKED,      // a script has camping blocked
    C_HIDEOUT,
    C_STORY_CAMP,   // at the gang's camp or Beecher's Hope
    C_INTERIOR,
    C_COMBAT,
    C_WANTED,
    C_CRIME,
    C_ACTIVITY,     // a random encounter, an ambush, a minigame, your horse, laying bait
    C_MISSION,
    C_GUARMA,
    C_LOCKDOWN,
    C_STORY_SPOT,   // a mission whose camp goes to a spot of its own
    C_KIT_OFF,      // the game has the camp kit disabled right now
    C_VEHICLE,      // in or on a vehicle, a boat or a train
};

static const char* CampReasonName(int r)
{
    switch (r)
    {
    case C_OK:          return "added (the kneel menu leaves its own out here)";
    case C_OFF:         return "off (SetUpCampAnywhere=0)";
    case C_UNSUPPORTED: return "off: the game's script globals don't match game build 1491.50";
    case C_GAME_HAS_IT: return "the kneel menu has its own here";
    case C_NO_LIST:     return "not added: the kneel menu's own buttons weren't found in the game's prompt list, "
                               "so the mod can't be sure it wouldn't make a second one";
    case C_NO_KIT:      return "not added: no camp kit";
    case C_CAMP_UP:     return "not added: a camp is already up";
    case C_BLOCKED:     return "not added: the game has camping blocked right now";
    case C_HIDEOUT:     return "not added: in a gang hideout";
    case C_STORY_CAMP:  return "not added: at the gang's camp";
    case C_INTERIOR:    return "not added: indoors";
    case C_COMBAT:      return "not added: in combat";
    case C_WANTED:      return "not added: wanted";
    case C_CRIME:       return "not added: a crime was committed recently";
    case C_ACTIVITY:    return "not added: something is going on nearby";
    case C_MISSION:     return "not added: on a mission";
    case C_GUARMA:      return "not added: in Guarma";
    case C_LOCKDOWN:    return "not added: the area is under lockdown";
    case C_STORY_SPOT:  return "not added: a mission with its own camp spot is under way";
    case C_KIT_OFF:     return "not added: the game has the camp kit disabled right now";
    case C_VEHICLE:     return "not added: on a vehicle, boat or train";
    }
    return "?";
}

static int  g_kneelThread     = 0;    // dynamic_craft_scenario's thread
static int  g_kneelOwnCamp    = -2;   // its own Set Up Camp: 1 there, 0 left out, -1 its prompts not found, -2 not looked yet
static int  g_kneelScanAt     = 0;
static int  g_campPrompt      = 0;
static int  g_lastCampReason  = -1;

enum CampPhase
{
    CP_IDLE,
    CP_LOADING,    // player_camp requested
    CP_STARTED,    // player_camp started: holding the kneel menu's buttons until Arthur is up
};
static int      g_campPhase   = CP_IDLE;
static int      g_campPhaseAt = 0;
static int      g_campState   = 0;    // player_camp's last state seen (it sets Global_43885 back to 0 as it ends)
static uint64_t g_campArgs[10];

// While player_camp gets going, the kneel menu's own buttons are hidden, as
// its Set Up Camp takes them away (func_24): they're its prompts, so only
// hidden, never deleted, and shown again if the camp doesn't start.
struct HiddenPrompt { int slot, prompt; };
static HiddenPrompt g_hidden[8];
static int          g_hiddenCount = 0;

static void HideKneelPrompts(int thread)
{
    g_hiddenCount = 0;
    if (!thread)
        return;
    for (int slot = 0; slot < 48 && g_hiddenCount < 8; slot++)
    {
        int base = G::kPromptList + 1 + slot * 18;
        if ((G::Int(base + 1, 0) & 2) == 0 || G::Int(base + 16, 0) != thread)
            continue;
        int p = G::Int(base + 3, 0);
        if (!N::PromptIsValid(p))
            continue;
        N::PromptSetVisible(p, 0);
        g_hidden[g_hiddenCount++] = { slot, p };
    }
}

static void ShowKneelPrompts(int thread)
{
    for (int i = 0; i < g_hiddenCount; i++)
    {
        int base = G::kPromptList + 1 + g_hidden[i].slot * 18;
        // still the kneel menu's prompt in that slot
        if ((G::Int(base + 1, 0) & 2) && G::Int(base + 16, 0) == thread && G::Int(base + 3, 0) == g_hidden[i].prompt &&
            N::PromptIsValid(g_hidden[i].prompt))
            N::PromptSetVisible(g_hidden[i].prompt, 1);
    }
    g_hiddenCount = 0;
}

static int FindThread(uint32_t hash)
{
    N::ThreadIteratorReset();
    for (int i = 0; i < 1000; i++)
    {
        int id = N::ThreadIteratorNext();
        if (id == 0)
            break;
        if (N::HashOfThread(id) == hash)
            return id;
    }
    return 0;
}

// The kneel menu's own prompts in the game's shared prompt list (its func_19
// and func_53 put each one in a slot: f_1 bit 2 in use, f_3 the prompt, f_4
// its control, f_16 the thread that made it). 1 if its Set Up Camp (E) is
// among them, 0 if not, -1 if none of its prompts are found (its Leave is
// always there, so then the list isn't where the plugin looks).
static int KneelOwnSetUpCamp(int thread)
{
    if (!thread)
        return -1;
    bool found = false, camp = false;
    for (int slot = 0; slot < 48; slot++)
    {
        int base = G::kPromptList + 1 + slot * 18;
        if ((G::Int(base + 1, 0) & 2) == 0 || G::Int(base + 16, 0) != thread)
            continue;
        if (!N::PromptIsValid(G::Int(base + 3, 0)))
            continue;
        found = true;
        if ((uint32_t)G::Int(base + 4, 0) == H_INPUT_CONTEXT_Y)
            camp = true;
    }
    return found ? (camp ? 1 : 0) : -1;
}

static void ScanKneelPrompts()
{
    g_kneelThread  = FindThread(H_DYNAMIC_CRAFT);
    g_kneelOwnCamp = KneelOwnSetUpCamp(g_kneelThread);
    if (g_cfg.debugLog)
        Log("The kneel menu's own buttons (thread %d): Set Up Camp %s.", g_kneelThread,
            g_kneelOwnCamp > 0 ? "there" : g_kneelOwnCamp == 0 ? "left out" : "not found");
}

// The camp kit the kneel menu's Set Up Camp would use: the first of KIT_CAMP
// and KIT_CAMP_SIMPLE in the player's inventory (the backup one while it's in
// use; func_15), that the button doesn't refuse (func_90: a kit a script has
// disabled is refused, unless the game is setting up a camp itself). 1 = a kit
// to use, 0 = no kit, -1 = a kit, but disabled.
static int CampKit()
{
    int inv = N::UsingBackupInventory() ? 5 : 1;
    int p2  = (G::Int(G::kInvFlagA, 0) || G::Int(G::kInvFlagB, 0)) ? 1 : 0;
    bool owned = false;
    const uint32_t kits[2] = { H_KIT_CAMP, H_KIT_CAMP_SIMPLE };
    for (uint32_t kit : kits)
    {
        if (!N::ItemKeyValid(kit) || N::ItemCount(inv, kit) < 1)
            continue;
        owned = true;
        if (!N::ItemDisabled(inv, kit, p2) || G::Int(G::kCampForced, 0) != 0)
            return 1;
    }
    return owned ? -1 : 0;
}

static float Dist2(const N::Vec3& a, const N::Vec3& b)
{
    float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return dx * dx + dy * dy + dz * dz;
}

// A flow is under way when its status is 3 or 4 (func_151, func_532).
static bool FlowUnderWay(int flowGlobal)
{
    int flow = G::Int(flowGlobal, 0);
    if (flow <= 0 || flow >= 771)
        return false;
    int st = G::Int(G::kFlowStatus + 1 + flow * 7 + 1, -1);
    return st == 3 || st == 4;
}

// Wanted or hunted, as the game counts it for camping (func_62 -> func_150(1, 1, 0);
// the decompiled scripts print a != b as "!a == b").
static bool LawAfterYou()
{
    int f13 = G::Int(G::kLaw + 13, 0), f15 = G::Int(G::kLaw + 15, 0), f17 = G::Int(G::kLaw + 17, 0);
    int f18 = G::Int(G::kLaw + 18, 0), f19 = G::Int(G::kLaw + 19, 0), f20 = G::Int(G::kLaw + 20, 0);
    int f21 = G::Int(G::kLaw + 21, 0);
    if (f18)
    {
        if (f19 > 0 || f17 > 0)
            return true;
    }
    else if ((uint32_t)f15 != H_LAW_DISPATCH_PENDING)
        return false;
    if (f20 > 0)
        return true;
    return f13 && f21 > 0;
}

static int CampAvailability(int ped, int player)
{
    if (!g_cfg.campAnywhere)
        return C_OFF;
    if (!g_globalsOk)
        return C_UNSUPPORTED;
    if (g_kneelOwnCamp > 0)
        return C_GAME_HAS_IT;
    if (g_kneelOwnCamp < 0)
        return C_NO_LIST;
    int kit = CampKit();
    if (kit == 0)
        return C_NO_KIT;
    if (kit < 0)
        return C_KIT_OFF;
    // The kneel menu's own conditions for its button, and func_21's that aren't
    // about the place, in func_21's order. (It runs every frame on its own
    // thread too, so all of them are cheap.)
    int campFlags2 = G::Int(G::kCampFlags2, 0);
    if ((campFlags2 & 1) && !(campFlags2 & (1 << 9)))
        return C_BLOCKED;
    if (G::Int(G::kZone, 0) & 4)
        return C_HIDEOUT;
    if (N::IsAnimalInteractionRunning(ped))
        return C_ACTIVITY;
    if (G::Int(G::kStoryCamp, 0) & (1 << 9))
        return C_STORY_CAMP;
    if (N::IsInteriorScene())
        return C_INTERIOR;
    if (N::IsPedInCombat(ped))
        return C_COMBAT;
    if (LawAfterYou())
        return C_WANTED;
    if (N::RecentCrime(player))
        return C_CRIME;
    if ((G::Int(G::kAmbush, 0) & 16) || G::Int(G::kEncounter, 0) != 0 || N::IsMinigameInProgress())
        return C_ACTIVITY;
    if (N::IsPedInAnyVehicle(ped) || (!N::IsPedRagdoll(ped) && N::IsPedOnVehicle(ped)) || N::IsPedInAnyBoat(ped) ||
        N::IsPlayerRidingTrain(player) || N::IsPedJacking(ped))
        return C_VEHICLE;
    if (G::Int(G::kOnMission, 0) && !(G::Int(G::kMissionCamp, 0) & 1))
        return C_MISSION;
    // func_21's last rule: not within 12 m of this stranger mission's spot while it runs
    if (N::ScriptThreads(H_RCM_EVELYN4) > 0)
    {
        N::Vec3 me = N::EntityCoords(ped);
        N::Vec3 spot = {};
        spot.x = G::Float(G::kEvelynSpot, 0.0f);
        spot.y = G::Float(G::kEvelynSpot + 1, 0.0f);
        spot.z = G::Float(G::kEvelynSpot + 2, 0.0f);
        if (Dist2(me, spot) < 144.0f)
            return C_MISSION;
    }
    if (G::Int(G::kDistrict, -1) == 8)
        return C_GUARMA;
    if (N::ScriptThreads(H_PLAYER_CAMP) > 0 || (G::Int(G::kCampIsUp, 0) & (1 << 23)) ||
        (G::Int(G::kCampFlags, 0) & G::CAMP_AT_FIRE))
        return C_CAMP_UP;
    int area = G::Int(G::kZoneArea, -1);
    if (area >= 0 && area <= 150 && (G::Int(G::kAreaFlags + 1 + area * 11, 0) & (1 << 25)))
        return C_LOCKDOWN;
    // Missions whose camp goes to a spot of its own (the button's func_114(120)
    // and func_66(15) cases): left to the game.
    if (FlowUnderWay(G::kCampFlow120) || FlowUnderWay(G::kCampFlow15))
        return C_STORY_SPOT;
    // The button's own check before it uses a kit (func_27 -> func_89)
    if (G::Int(G::kItemUseOff, 0) != 0)
        return C_ACTIVITY;
    return C_OK;
}

// A full camp (with the tent the horse carries) when the active horse is
// within whistling range and isn't away, or you're leading a horse; otherwise
// a small one (flags 128 and 32). As the button works it out (func_27, KIT_CAMP).
static bool FullCamp(int ped)
{
    N::Vec3 me = N::EntityCoords(ped);
    bool nearActive = false;
    int slot = G::Int(G::kActiveHorse, -1);
    if (slot >= 0 && slot < 7)
    {
        int horse = G::Int(G::kHorsePeds + 1 + slot * 45, 0);
        float range = WhistleRange(slot);   // -1 for a saved model the game won't take: then 1 m, as the game squares it
        if (horse && N::DoesEntityExist(horse))
            nearActive = Dist2(me, N::EntityCoords(horse)) <= range * range;
    }
    int led = G::Int(G::kLedHorse, 0);
    bool nearLed = led && N::DoesEntityExist(led) && Dist2(me, N::EntityCoords(led)) <= 25.0f;
    return !((!nearActive || G::Int(G::kHorseAway, 0) != 0) && !nearLed);
}

static void DeleteCampPrompt()
{
    if (g_campPrompt)
    {
        if (N::PromptIsValid(g_campPrompt))
            N::PromptDelete(g_campPrompt);
        g_campPrompt = 0;
    }
}

// Built as the kneel menu builds its own Set Up Camp (func_19 -> func_53:
// priority 1, a tap that fires on press), in its group, with its label.
static void CreateCampPrompt()
{
    int p = N::PromptRegisterBegin();
    N::PromptSetControlAction(p, H_INPUT_CONTEXT_Y);
    N::PromptSetText(p, N::DoesTextLabelExist("SET_CAMP") ? "SET_CAMP" : N::VarStringLiteral("Set Up Camp"));
    N::PromptSetPriority(p, 1);
    N::PromptSetTransportMode(p, 0);
    N::PromptSetAttribute(p, 18, 1);
    N::PromptSetStandardMode(p, 0);
    N::PromptRegisterEnd(p);
    N::PromptSetGroup(p, kRestGroup, 0);
    N::PromptSetVisible(p, 1);
    N::PromptSetEnabled(p, 1);
    g_campPrompt = p;
}

static void StartCamp(int now, int ped)
{
    DeletePrompt();
    DeleteCampPrompt();
    if (!N::DoesScriptExist("player_camp"))
    {
        Log("ERROR: the game has no player_camp script.");
        HelpText(nullptr, "The camp couldn't be set up.");
        return;
    }
    // player_camp's arguments, as the button passes them: the flags, 0, 0, 0,
    // 0, 1, and a camp spot that only some missions give (here none).
    bool full = FullCamp(ped);
    memset(g_campArgs, 0, sizeof g_campArgs);
    g_campArgs[0] = full ? 0u : (128u | 32u);
    g_campArgs[5] = 1;
    N::RequestScript("player_camp");
    HideKneelPrompts(g_kneelThread);
    g_campPhase   = CP_LOADING;
    g_campPhaseAt = now;
    Log("Set Up Camp pressed: starting the game's camp (%s, flags %d).",
        full ? "a full camp, the horse is near" : "a small camp, the horse isn't near", (int)g_campArgs[0]);
}

static void CampTick(int now, int ped)
{
    // The kneel menu's other buttons are held while it's still there (until
    // player_camp has Arthur up), as its own Set Up Camp takes them away.
    bool kneelOver = N::ScriptThreads(H_DYNAMIC_CRAFT) <= 0;
    if (!kneelOver)
    {
        N::DisableControlAction(H_INPUT_CONTEXT_X);
        N::DisableControlAction(H_INPUT_CONTEXT_Y);
        N::DisableControlAction(H_INPUT_CONTEXT_B);
        N::DisableControlAction(g_control ? g_control : Joaat("INPUT_CONTEXT_A"));
        N::DisableControlAction(H_INPUT_JUMP);
    }

    int age = now - g_campPhaseAt;
    switch (g_campPhase)
    {
    case CP_LOADING:
        if (N::IsEntityDead(ped))
        {
            N::ScriptNoLongerNeeded("player_camp");
            Log("Set Up Camp: the player died before the camp script had loaded; not started.");
            g_hiddenCount = 0;
            g_campPhase = CP_IDLE;
        }
        else if (age > 5000)
        {
            N::ScriptNoLongerNeeded("player_camp");
            Log("ERROR: the game's camp script didn't load within 5 s.");
            HelpText(nullptr, "The camp couldn't be set up. Try again.");
            ShowKneelPrompts(g_kneelThread);
            g_campPhase = CP_IDLE;
        }
        else if (N::HasScriptLoaded("player_camp"))
        {
            int thread = N::StartScriptWithArgs("player_camp", g_campArgs, 10, 6096);
            N::ScriptNoLongerNeeded("player_camp");
            if (thread)
            {
                Log("The game's camp script is running.");
                g_campPhase   = CP_STARTED;
                g_campPhaseAt = now;
                g_campState   = 0;
            }
            else
            {
                Log("ERROR: the game's camp script didn't start.");
                HelpText(nullptr, "The camp couldn't be set up. Try again.");
                ShowKneelPrompts(g_kneelThread);
                g_campPhase = CP_IDLE;
            }
        }
        break;

    case CP_STARTED:
    {
        // player_camp gets Arthur up (its state 1), looks for the nearest
        // campsite (2) and pitches the camp there (3 on), or gives up with the
        // game's "Cannot create camp in this location." (14) and ends. Followed
        // until it's past that, for the log.
        bool campOver = N::ScriptThreads(H_PLAYER_CAMP) <= 0;
        int  state    = G::Int(G::kCampState, 0);
        if (!campOver && state != 0)
            g_campState = state;
        if (campOver)
        {
            Log("Set Up Camp: the game's camp script ended (last state %d)%s.", g_campState,
                g_campState == 14 ? ": it found no campsite to use here" : "");
            if (!kneelOver)
                ShowKneelPrompts(g_kneelThread);
            g_campPhase = CP_IDLE;
        }
        else if (kneelOver && g_campState >= 3 && g_campState != 14)
        {
            Log("Set Up Camp: Arthur is up, the game is pitching the camp (state %d).", g_campState);
            g_hiddenCount = 0;
            g_campPhase = CP_IDLE;
        }
        else if (age > 10000)
        {
            Log("Set Up Camp: %s 10 s on (camp state %d), letting go.",
                kneelOver ? "the camp isn't up" : "Arthur is still kneeling", g_campState);
            if (!kneelOver)
                ShowKneelPrompts(g_kneelThread);
            g_hiddenCount = 0;
            g_campPhase = CP_IDLE;
        }
        break;
    }
    }
}

static void CampPromptTick(int now, int ped, int player)
{
    // The kneel menu's own buttons: its thread is looked up once per kneel (and
    // again every second if it wasn't found), its prompts every frame, so that
    // a rebuilt set of them is seen at once.
    if (g_cfg.campAnywhere)
    {
        if (g_kneelOwnCamp == -2 || (!g_kneelThread && now - g_kneelScanAt > 1000))
        {
            g_kneelScanAt = now;
            ScanKneelPrompts();
        }
        else if (g_kneelThread)
        {
            int own = KneelOwnSetUpCamp(g_kneelThread);
            if (own != g_kneelOwnCamp)
            {
                if (g_cfg.debugLog)
                    Log("The kneel menu's own buttons now: Set Up Camp %s.",
                        own > 0 ? "there" : own == 0 ? "left out" : "not found");
                g_kneelOwnCamp = own;
            }
        }
    }
    int cr = CampAvailability(ped, player);
    if (cr != g_lastCampReason)
    {
        Log("Set Up Camp: %s.", CampReasonName(cr));
        g_lastCampReason = cr;
    }
    if (cr != C_OK)
    {
        DeleteCampPrompt();
        return;
    }
    bool pressed = g_campPrompt && N::PromptIsValid(g_campPrompt) && N::PromptIsJustPressed(g_campPrompt);
    if (!g_campPrompt || !N::PromptIsValid(g_campPrompt))
    {
        g_campPrompt = 0;
        CreateCampPrompt();
    }
    if (pressed)
        StartCamp(now, ped);
}

// ===========================================================================
// The kneel menu watch
// ===========================================================================

static bool g_kneelUp     = false;
static int  g_lastReason  = -1;
static int  g_lastWaypoint = -1;     // the WaypointUse last logged
static int  g_lastHelpAt  = -100000;
static int  g_lastHelpWhy = -1;
static int  g_iniCheckAt  = 0;
static int  g_kneelSeenAt = -100000;  // last time a kneel was going on
static int  g_pressAt     = -1;       // Fast Travel pressed, the menu not opened yet: when

// The fast travel menu can open: Arthur is all the way down (short_update
// closes its menu until then, func_502), and the CAMP text is in, since the
// menu's own heading comes from it (CAMP_FT_HEADER, CAMP_FT_SUB). The text is
// waited for 1 s at most.
static bool ReadyForMenu(int ped, int now)
{
    return FullyKneeling(ped) && (CampTextLoaded() || now - g_pressAt > 1000);
}

static void LogKneelDetails(int ped)
{
    int lodging, flow;
    int unlocked = FastTravelUnlocked(&lodging, &flow);
    HorseInfo a, b;
    int horse = HorseCheck(ped, &a, &b);
    int hud = G::Int(G::kKneelHud, 0);
    Log("Kneel menu up. Game fast travel state %d, flags %d, camp bit 23 %d, kneel prompts bit %d, all the way "
        "down %d, CAMP text %s; unlocked %d (lodging %d, flow status %d); horse: %s",
        G::Int(G::kFtState, -1), G::Int(G::kFtFlags, -1),
        (G::Int(G::kCampFlags, 0) & G::CAMP_AT_FIRE) ? 1 : 0, (hud >> 2) & 1, FullyKneeling(ped) ? 1 : 0,
        CampTextLoaded() ? "loaded" : "not loaded", unlocked, lodging, flow, ReasonName(horse));
    Log("  active horse: slot %d ped %d %s, %.1f m, whistle range %.1f m; slot 1: ped %d %s, %.1f m, range %.1f m",
        a.slot, a.ped, !a.exists ? "none" : a.dead ? "dead" : "alive", a.dist, a.range,
        b.ped, !b.exists ? "none" : b.dead ? "dead" : "alive", b.dist, b.range);
    if (N::IsWaypointActive())
    {
        N::Vec3 me = N::EntityCoords(ped), wp = N::WaypointCoords();
        float dx = wp.x - me.x, dy = wp.y - me.y, d = 0.0f;
        int wu = WaypointUseFor(ped, &d);
        Log("  waypoint: %.0f m away (GPS route %s, %d m, %s); Fast Travel: %s",
            sqrtf(dx * dx + dy * dy), N::GpsRouteFound() ? "found" : "not found", N::GpsRouteLength(),
            N::GpsPathOnRoad() ? "on roads" : "not on roads", WaypointUseText(wu, d));
    }
    else
        Log("  waypoint: none");
}

static void DropPress(const char* why)
{
    if (g_pressAt < 0)
        return;
    g_pressAt = -1;
    Log("Fast Travel: dropped the press, the menu didn't open (%s).", why);
}

// The Fast Travel prompt while the kneel menu is up. True once a fast travel
// request has gone in.
static bool FtPromptTick(int now, int ped, int player)
{
    if (!g_cfg.enabled)
    {
        DropPress("Fast Travel is off");
        DeletePrompt();
        return false;
    }

    // With a waypoint on the map the button takes you there; without one (or
    // one it can't take you to) it opens the game's fast travel menu.
    float wpDist = 0.0f;
    int wu = WaypointUseFor(ped, &wpDist);
    bool waypoint = wu == WU_GO;
    int r = Availability(ped, player, waypoint);
    if (r != g_lastReason || wu != g_lastWaypoint)
    {
        if (r == R_OK)
            Log("Fast Travel: available (%s).", WaypointUseText(wu, wpDist));
        else
            Log("Fast Travel: %s.", ReasonName(r));
        g_lastReason = r;
        g_lastWaypoint = wu;
    }

    // The kneel menu shows its prompts before Arthur is all the way down, but
    // short_update closes its menu straight away until he is (func_502). So a
    // press from before then goes in once he's down (see ReadyForMenu).
    if (g_pressAt >= 0)
    {
        if (waypoint)
            DropPress("a waypoint was set meanwhile");
        else if (r != R_OK)
        {
            DropPress(ReasonName(r));
            g_lastHelpAt = now;
            g_lastHelpWhy = r;
            ShowReason(r);
        }
        else if (ReadyForMenu(ped, now))
        {
            Log("Ready %.1f s after the press: opening the fast travel menu.", (now - g_pressAt) / 1000.0);
            g_pressAt = -1;
            StartRequest(now);
            return true;
        }
        else if (now - g_pressAt > 3000)
            DropPress("Arthur wasn't all the way down 3 s later");
    }

    if (r != R_OK && !g_cfg.showWhenUnavailable)
    {
        DeletePrompt();
        return false;
    }

    // The press, read before the prompt might be replaced below.
    bool pressed = g_prompt && N::PromptIsValid(g_prompt) && N::PromptIsJustReleased(g_prompt);

    CheckPromptText();
    if (!g_prompt || !N::PromptIsValid(g_prompt))
    {
        g_prompt = 0;
        CreatePrompt();
    }
    int want = r == R_OK ? 1 : 0;
    if (want != g_promptEnabled)
    {
        N::PromptSetEnabled(g_prompt, want);
        g_promptEnabled = want;
    }

    // Space is also Jump: nothing else should happen on it while kneeling.
    N::DisableControlAction(H_INPUT_JUMP);

    if (r == R_OK)
    {
        if (pressed && waypoint)
        {
            StartWaypointTravel(now, ped);
            return true;
        }
        if (pressed && g_pressAt < 0)
        {
            if (wu == WU_NEW_AUSTIN || wu == WU_BLACKWATER)
                HelpText(nullptr, wu == WU_NEW_AUSTIN ? "Fast travel can't take Arthur to New Austin. Pick a place instead."
                                                      : "Fast travel can't take Arthur to Blackwater. Pick a place instead.");
            g_pressAt = now;
            if (ReadyForMenu(ped, now))
            {
                g_pressAt = -1;
                StartRequest(now);
                return true;
            }
            else if (!FullyKneeling(ped))
                Log("Fast Travel pressed while Arthur is still getting down: the menu opens once he's down.");
            else
                Log("Fast Travel pressed: the menu opens once the CAMP text is in (the menu's heading).");
        }
    }
    else if (N::IsDisabledControlJustReleased(g_control) && (r != g_lastHelpWhy || now - g_lastHelpAt > 1500))
    {
        // One message per press, at most every 1.5 s for the same reason.
        g_lastHelpAt = now;
        g_lastHelpWhy = r;
        ShowReason(r);
    }
    return false;
}

static void IdleTick(int now, int ped, int player)
{
    // The settings file, every 2 s (and at once when a kneel starts): changes
    // apply without a restart. The prompts are made again with them.
    if (now - g_iniCheckAt > 2000)
    {
        g_iniCheckAt = now;
        if (IniChanged())
        {
            LoadSettings();
            DeletePrompt();
            DeleteCampPrompt();
            g_lastReason = g_lastCampReason = -1;
        }
    }

    // A kneel has started (dynamic_craft_scenario runs from its first moment):
    // load the CAMP text now, so the label is ready by the time the kneel menu
    // shows its prompts. Let it go again a while after the kneel is over.
    bool watching = g_cfg.enabled || g_cfg.campAnywhere;
    bool kneeling = watching && N::ScriptThreads(H_DYNAMIC_CRAFT) > 0 && !N::IsEntityDead(ped);
    if (kneeling)
    {
        g_kneelSeenAt = now;
        if (g_cfg.enabled)
            RequestCampText(now);
    }
    else
    {
        g_kneelHudSeen = false;   // the next kneel starts afresh
        if (now - g_kneelSeenAt > 3000)
            ReleaseCampText(now);
    }

    bool up = kneeling && KneelMenuUp(ped, player);
    if (up != g_kneelUp)
    {
        g_kneelUp = up;
        g_lastReason = g_lastCampReason = -1;
        g_kneelOwnCamp = -2;   // the kneel menu's own buttons are looked at afresh
        if (up)
        {
            WaypointZonesStale();
            if (IniChanged())
            {
                LoadSettings();
                g_iniCheckAt = now;
                up = (g_cfg.enabled || g_cfg.campAnywhere) && KneelMenuUp(ped, player);
                g_kneelUp = up;
            }
            if (up)
            {
                if (!g_globalsOk)
                {
                    char why[200];
                    g_globalsOk = CheckGlobals(ped, why, sizeof why);
                    if (g_globalsOk)
                        Log("Script globals look right (game build 1491.50 layout).");
                    else
                        Log("ERROR: the game's script globals don't look like build 1491.50 (%s). "
                            "Fast travel stays off.", why);
                }
                LogKneelDetails(ped);
            }
        }
        else
        {
            if (g_cfg.debugLog)
                Log("Kneel menu down.");
        }
    }

    if (!up)
    {
        DropPress("the kneel menu closed");
        DeletePrompt();
        DeleteCampPrompt();
        return;
    }

    if (FtPromptTick(now, ped, player))
        return;
    CampPromptTick(now, ped, player);
    if (g_campPhase != CP_IDLE)
        DropPress("Set Up Camp was pressed");
}

// ===========================================================================
// Main loop
// ===========================================================================

static void ScriptMain()
{
    Log("Script started.");
    InitHashes();
    LoadSettings();
    if (SH_getGameVersion)
        Log("Script Hook reports game version id %d", SH_getGameVersion());

    bool shownLoaded = false;
    bool wasOnline   = false;

    for (;;)
    {
        bool online = N::NetworkIsSessionStarted() || N::NetworkIsGameInProgress();
        if (online != wasOnline)
        {
            Log(online ? "Online session detected - mod idle." : "Back in Story Mode.");
            wasOnline = online;
            if (online)
            {
                DeletePrompt();
                RestoreCampBit();
                g_phase = PH_IDLE;
                g_kneelUp = false;
                g_pressAt = -1;
                g_campTextOurs = false;   // Red Dead Online has its own camps: leave the text to it
                g_campTextAskedAt = -1;
                g_campTextSeen = false;
                DeleteCampPrompt();
                if (g_campPhase == CP_LOADING)
                    N::ScriptNoLongerNeeded("player_camp");
                g_campPhase = CP_IDLE;
                g_hiddenCount = 0;
            }
        }
        // A save loading or an online session during a trip to the waypoint: gone with the old world.
        if (g_wtPhase != WT_IDLE && (online || N::IsLoadingScreenActive()))
            WtDrop(online ? "an online session started" : "a loading screen came up");

        int ped = online ? 0 : N::PlayerPedId();
        if (!online && ped != 0 && !N::IsLoadingScreenActive())
        {
            int now = N::GameTimer();
            int player = N::PlayerId();

            if (!shownLoaded && N::IsFadedIn())
            {
                shownLoaded = true;
                if (!SH_getGlobalPtr)
                    Notify(9000, true, "%s %s: your Script Hook RDR2 has no getGlobalPtr - see FastTravelAnywhere.log",
                           FTA_NAME, FTA_VERSION);
                else if (g_cfg.showLoadMessage)
                    Notify(6000, false,
                           g_cfg.enabled && g_cfg.campAnywhere ? "%s %s loaded - hold E to kneel: Space to Fast Travel, E to Set Up Camp anywhere" :
                           g_cfg.enabled ? "%s %s loaded - hold E to kneel, then Space: Fast Travel" :
                           g_cfg.campAnywhere ? "%s %s loaded - hold E to kneel, then E: Set Up Camp anywhere" :
                                                "%s %s loaded - OFF (Enabled=0 and SetUpCampAnywhere=0 in FastTravelAnywhere.ini)",
                           FTA_NAME, FTA_VERSION);
            }

            if (g_phase != PH_IDLE)
                FlowTick(now, ped);
            else if (g_wtPhase != WT_IDLE)
                WaypointTick(now, ped);
            else if (g_campPhase != CP_IDLE)
                CampTick(now, ped);
            else if (!N::IsPauseMenuActive())
                IdleTick(now, ped, player);
            else
                DeleteCampPrompt();   // the kneel menu's buttons aren't watched while paused: no Set Up Camp of ours
        }

        DrawNotification();
        SH_scriptWait(0);
    }
}

// ===========================================================================
// DLL entry
// ===========================================================================

// The only export. Handy for identifying the build, and its presence also
// stops MinGW-style linkers from auto-exporting every internal function.
extern "C" __declspec(dllexport) const char* FastTravelAnywhereVersion()
{
    return FTA_VERSION;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID reserved)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(hModule);
        BuildPaths(hModule);
        ResetLog();
        Log("%s %s loading (%s)", FTA_NAME, FTA_VERSION, g_logPath);
        if (BindScriptHook())
        {
            SH_scriptRegister(hModule, ScriptMain);
            g_registered = true;
            Log("Registered with Script Hook RDR2. Waiting for Story Mode to start.");
        }
    }
    else if (reason == DLL_PROCESS_DETACH)
    {
        // reserved != NULL means the process is exiting: leave everything as is.
        if (reserved == nullptr && g_registered && SH_scriptUnregister)
            SH_scriptUnregister(hModule);
    }
    return TRUE;
}
