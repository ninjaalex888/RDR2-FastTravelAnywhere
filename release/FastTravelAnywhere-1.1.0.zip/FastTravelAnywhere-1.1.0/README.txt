FAST TRAVEL ANYWHERE  v1.1.0
Red Dead Redemption 2 (PC) - Story Mode
=====================================================================

Hold E to kneel anywhere, and the kneel menu in the bottom-right corner
(Craft, Set Up Camp, Leave) gets a Fast Travel button on Space (A on a
controller), the same button a campfire has. It opens the game's own fast
travel menu: the same list of places, the same trip with your horse, the
same rules as at a campfire.

And Set Up Camp (E) is there wherever you kneel, towns included. Where the
game leaves it out of the kneel menu, the mod puts it in, and the game makes
camp at the nearest of its own campsites: from a town, just outside it.


REQUIREMENTS
------------
* RDR2 on PC (Steam, Rockstar Games Launcher or Epic), current version
  (game build 1491.50).
* Script Hook RDR2 by Alexander Blade:
  http://www.dev-c.com/rdr2/scripthookrdr2/
  Get the latest version. Its zip contains ScriptHookRDR2.dll and
  dinput8.dll; both go in the game folder.


INSTALL
-------
1. Open your game folder (the one with RDR2.exe). On Steam:
   Library > right-click Red Dead Redemption 2 > Manage > Browse local files.
2. Copy FastTravelAnywhere.asi and FastTravelAnywhere.ini into it.
3. Start the game and load Story Mode. A yellow message appears in the
   top-left corner for a few seconds:
     Fast Travel Anywhere 1.1.0 loaded - hold E to kneel: Space to
     Fast Travel, E to Set Up Camp anywhere

To uninstall, delete FastTravelAnywhere.asi, FastTravelAnywhere.ini and
FastTravelAnywhere.log.


USING IT
--------
1. Hold E with nothing around you to kneel. The kneel menu appears in the
   bottom-right corner, now with Fast Travel on Space.
2. Press Space. The game's fast travel menu opens, the same one as at a
   campfire. You can press it as soon as it appears: if Arthur is still
   getting down, the menu opens the moment he's down.
3. Pick a place. Arthur stands up, the screen fades out, and you arrive at
   the place on your horse. Back out of the menu to stay where you are.

In the menu, use the arrow keys, the mouse or the D-pad. W/S or the left
stick might make Arthur get up from the kneel, which closes the menu (see
TROUBLESHOOTING).


SET UP CAMP ANYWHERE
--------------------
Out in the wilderness the kneel menu has its own Set Up Camp, and the mod
leaves it alone. In a town, near train tracks or next to someone with a
mission for you, the game leaves it out; there the mod adds it, on the same
button (E), with the game's own text. Press it and the game does what its
own button does: Arthur gets up, pitches camp, the screen fades, and you're
at your camp, set up at the nearest of the game's campsites (from a town,
just outside it). A full camp when your horse is within whistling range, a
small one when it isn't, as the game decides.


THE RULES
---------
Fast Travel follows the game's own rules for fast travel at a campfire:

* Fast travel has to be unlocked, as for your camp (for Arthur: the
  lodging upgrade in the camp ledger).
* Your horse has to be alive and within whistling range: it travels with
  you.
* Not while you're wanted, and not during a mission.
* You have to have discovered somewhere to go.

Which places are listed, and which are off-limits (such as New Austin for
Arthur), is decided by the game itself, as at a campfire.

When the button can't be used it's shown greyed out, and pressing it says
why, with the game's own message where it has one ("Your horse is too far
away to fast travel." and so on). The unlock, horse, wanted and mission
rules can each be relaxed in FastTravelAnywhere.ini.

Set Up Camp keeps all of the game's camping rules except the ones about the
place: you need a camp kit, and it isn't added while you're wanted or have
just committed a crime, in combat, on a mission (unless the mission lets you
camp), indoors, in a gang hideout, at the gang's camp, in Guarma, in an area
under lockdown, during a random encounter, an ambush or a minigame, while
busy with your horse, or with a camp already up. If the game finds no
campsite to use, it says so itself ("Cannot create camp in this location.").


SETTINGS (FastTravelAnywhere.ini)
---------------------------------
Changes take effect within a couple of seconds, no restart needed.

Enabled=1              Fast Travel in the kneel menu on/off.
SetUpCampAnywhere=1    Set Up Camp in the kneel menu wherever you kneel.
                       0 = only where the game offers it itself.
RequireUnlock=1        Fast travel has to be unlocked, as for your camp.
RequireHorseNearby=1   Your horse has to be within whistling range.
                       0 = also when it's too far away: you arrive on foot.
                       A living horse is always needed (the game's menu
                       closes without one).
AllowWhenWanted=0      1 = allow fast travel while wanted.
AllowOnMissions=0      1 = allow fast travel during a mission.
ShowWhenUnavailable=1  Show the button greyed out when it can't be used;
                       pressing it says why. 0 = hide it, as a campfire does.
StandUp=1              Arthur stands up as the screen fades out.
PromptControl=INPUT_CONTEXT_A
                       The button, by the game's control name.
                       INPUT_CONTEXT_A is Space (A on a controller). The
                       kneel menu already uses R, E and F.
PromptText=            Empty = the game's own "Fast Travel" text, in your
                       game's language.
ShowLoadMessage=1      The "loaded" message when Story Mode starts.
DebugLog=0             More detail in FastTravelAnywhere.log.
LockMovementInMenu=0   Experimental. If the menu closes when you scroll it
                       with W/S or the left stick, 1 switches the controls
                       to menu-only while it's open.


TROUBLESHOOTING
---------------
* No message when Story Mode loads: check ScriptHookRDR2.log in the game
  folder (update Script Hook if it says your game version isn't
  supported), then FastTravelAnywhere.log.

* No Fast Travel in the kneel menu: FastTravelAnywhere.log gets a
  "Kneel menu up." line each time you kneel, with the game's fast travel
  state, the unlock check and your horse, then a "Fast Travel added to the
  kneel menu (...)" line that says which text it shows. No such lines mean
  the mod didn't see the kneel menu.

* Fast Travel is greyed out: press it to see why. The log has a
  "Fast Travel: ..." line with the reason too.

* "doesn't recognise this version of the game": the mod checks the game's
  internals before it changes anything, and they don't match the version
  it was made for. It stays off and changes nothing.

* The menu closes when you scroll it: with W/S or the left stick, Arthur
  may get up from the kneel, and the game closes the menu when he does.
  Use the arrow keys, the mouse or the D-pad, or set LockMovementInMenu=1.
  The log has a "The fast travel menu closed without a choice ..." line
  with everything the game checks; please include it if you report this.

* No Set Up Camp in a town: the log has a "Set Up Camp: ..." line each
  time you kneel that says why ("not added: wanted", "not added: no camp
  kit" and so on), or "the kneel menu has its own here" where the game
  offers it itself.

* Set Up Camp pressed, but no camp: the log follows the game's camp script
  ("Set Up Camp pressed: ...", "The game's camp script is running.", then
  how it went). "it found no campsite to use here" means the game had no
  campsite for that part of the map; it says "Cannot create camp in this
  location." itself.


HOW IT WORKS
------------
A campfire's Fast Travel button doesn't travel by itself: it hands the
request to one of the game's own scripts, which opens the fast travel menu
and makes the trip, while the campfire plays its part (it lets the menu
stay open while you're at the fire, then kicks out the fire, fades the
screen and packs up when you pick a place). This mod plays the campfire's
part from the kneel menu: it hands over the same request, and when you pick
a place, Arthur stands up and the screen fades. The game does the rest.

Set Up Camp: the kneel menu adds its own Set Up Camp only where the game
allows a camp. The mod looks at the kneel menu's buttons in the game's list
of prompts, and only when they're there without a Set Up Camp does it add
one, so there are never two. A press starts the game's camp script with the
same settings the kneel menu's own button gives it; the game picks the
campsite and does the rest.

Before it changes anything, the mod checks that the game's internals match
the version it was made for. If the game doesn't respond, the mod takes the
request back and turns itself off until the game restarts. Idle in Red Dead
Online.


CHANGES
-------
1.1.0  Set Up Camp anywhere. Where the game leaves Set Up Camp out of the
       kneel menu (in a town, say), the mod adds it on E, and the game makes
       camp at the nearest of its campsites, outside town. Its other camping
       rules still apply. New setting SetUpCampAnywhere (on by default).
       Settings changes now apply within a couple of seconds, without
       kneeling again.
1.0.1  Fast Travel always shows its name now. It could be missing from the
       kneel menu, after a trip for example, while Space still worked: its
       text lives in a part of the game's text that only the camp scripts
       load, and the mod now loads it itself. Fast Travel also comes up
       together with the kneel menu's own buttons instead of up to a
       second later, and goes away with them (after Set Up Camp, for
       example). Greyed out while the journal or satchel is open.
1.0.0  First release.


RED DEAD ONLINE
---------------
Story Mode only. Script Hook RDR2 doesn't run in Red Dead Online, and this
mod also stays idle if it detects an online session. Rockstar still bans
for modded files in Online, so remove or disable your mods (including
Script Hook's dinput8.dll) before playing Online.


CREDITS
-------
Script Hook RDR2: Alexander Blade
RDR3 native database: alloc8or
Decompiled game scripts and native enums: Halen84
Controls, input contexts and other game data: femga (rdr3_discoveries)
